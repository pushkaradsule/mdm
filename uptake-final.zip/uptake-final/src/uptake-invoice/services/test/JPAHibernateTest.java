import akka.actor.ActorSystem;
import com.uptake.invoice.dataaccess.InvoiceDao;
import com.uptake.invoice.dataaccess.InvoiceDaoImp;
import com.uptake.invoice.entities.Invoice;
import com.uptake.invoice.executioncontext.InvoiceExecutionContext;

import com.uptake.invoice.resources.InvoiceResource;
import org.h2.tools.RunScript;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.junit.*;
import play.db.jpa.JPAApi;

import javax.persistence.*;
import javax.persistence.criteria.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by apurvav on 31-07-2017.
 */
public class JPAHibernateTest {

    private static EntityManagerFactory emf;
    private static EntityManager em;

    @BeforeClass
    public static void init() throws FileNotFoundException, SQLException {
        emf = Persistence.createEntityManagerFactory("testPersistenceUnit");
        em = emf.createEntityManager();
    }

    @Before
    public void initializeDatabase() {
        Session session = em.unwrap(Session.class);
        session.doWork(new Work() {
            @Override
            public void execute(Connection connection) throws SQLException {
                try {
                    File script = new File(getClass().getResource("/data.sql").getFile());
                    RunScript.execute(connection, new FileReader(script));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException("could not initialize with script");
                }
            }
        });
    }

    @Test
    public void should_get_all_invoices_from_db() {
        Query query = em.createQuery("select i from Invoice i");
        assertEquals(7, query.getResultList().size());
    }

    @AfterClass
    public static void tearDown() {
        em.clear();
        em.close();
        emf.close();
    }

}
