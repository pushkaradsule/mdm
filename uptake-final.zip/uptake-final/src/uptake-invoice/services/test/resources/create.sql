CREATE TABLE `invoices` (
  `customerId` INT(11) NOT NULL AUTO_INCREMENT,
  `customerNumber` varchar(12) NOT NULL,
  `customerType` varchar(5) NOT NULL,
  `invoiceType` varchar(5) NOT NULL,
  `invoiceAmt` DECIMAL (65,5) NOT NULL,
  `invoiceStatus` varchar(12) NOT NULL,
  `invoiceDate` Date NOT NULL,
  PRIMARY KEY (`customerId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 ;
