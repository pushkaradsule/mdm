import com.uptake.invoice.common.GenericResponse;
import com.uptake.invoice.dataaccess.UserDao;
import com.uptake.invoice.entities.User;
import com.uptake.invoice.resources.UserResource;
import com.uptake.invoice.security.Cryptographer;
import com.uptake.invoice.services.UserService;

import org.junit.Assert;

import org.junit.Test;
import play.libs.Json;
import play.libs.concurrent.*;

import java.util.Optional;
import java.util.concurrent.*;

import static org.mockito.Mockito.*;


public class UserServiceTest {

    @Test
    public void valid_user_should_be_able_to_login() throws ExecutionException, InterruptedException {

        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        UserDao repositoryMock = mock(UserDao.class);

        User u = new User();
        u.setEmail("a@a.com");

        u.setPasswordSalt(Cryptographer.getNextSalt());
        u.setPassword(Cryptographer.generateHashedPassword("1234", u.getPasswordSalt()));

        when(repositoryMock.getUserByUserName(any(String.class))).
                thenReturn(CompletableFuture.completedFuture(Optional.of(u)));


        // Test Service
        UserService userService = new UserService(repositoryMock, ecProvider);

        CompletableFuture<GenericResponse<Object>> future = userService.validateUserByUserNameAndPassword
                ("a@a.com", "1234").thenApplyAsync(
                data -> {
                    // Assert.assertEquals(true,false);
                    return data;
                }


        ).toCompletableFuture();

        Assert.assertEquals(future.get().isSuccess, true);
        Assert.assertEquals(future.isDone(), true);
        Assert.assertEquals(future.get().getErrorMessage().size(), 0);
        Assert.assertEquals(future.get().getValidationMessage().size(), 0);

    }


    @Test
    public void user_should_should_get_proper_error_message_for_invalid_credentials() throws ExecutionException, InterruptedException {

        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        UserDao repositoryMock = mock(UserDao.class);

        User u = new User();
        u.setEmail("a@a.com");

        u.setPasswordSalt(Cryptographer.getNextSalt());
        u.setPassword(Cryptographer.generateHashedPassword("1234", u.getPasswordSalt()));

        when(repositoryMock.getUserByUserName(any(String.class))).
                thenReturn(CompletableFuture.completedFuture(Optional.of(u)));

        // Test Service
        UserService userService = new UserService(repositoryMock, ecProvider);

        CompletableFuture<GenericResponse<Object>> future = userService.validateUserByUserNameAndPassword
                ("a@a111.com", "12314").thenApplyAsync(
                data -> {
                    // Assert.assertEquals(true,false);
                    return data;
                }


        ).toCompletableFuture();

        Assert.assertEquals(future.get().isSuccess, false);
        Assert.assertEquals(future.isDone(), true);
        Assert.assertEquals(future.get().getErrorMessage().size(), 1);
        Assert.assertEquals(future.get().getValidationMessage().size(), 0);
        Assert.assertEquals(future.get().getErrorMessage().stream().anyMatch(a -> a.containsKey("LOGIN_FAILED")),
                true);



    }


    @Test
    public void user_should_be_able_get_valid_profile() throws ExecutionException, InterruptedException {


        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        UserDao repositoryMock = mock(UserDao.class);

        User u = new User();

        u.setEmail("a@a.com");
        u.setFirstName("pushkar");
        u.setLastName("adsule");


        when(repositoryMock.getUserByUserName(any(String.class))).
                thenReturn(CompletableFuture.completedFuture(Optional.of(u)));

        // Test Service
        UserService userService = new UserService(repositoryMock, ecProvider);


        CompletableFuture<Optional<UserResource>> future = userService.getUserProfile("a@a.com")
                .thenApplyAsync(
                        data -> data

                ).toCompletableFuture();

        UserResource response = future.get().get();

        Assert.assertEquals(future.isDone(), true);


        Assert.assertEquals(response.getFirstName(), "pushkar");
        Assert.assertEquals(response.getLastName(), "adsule");
        Assert.assertEquals(response.getUserName(), "a@a.com");
        Assert.assertEquals(null, response.getPassword());

    }


    @Test
    public void system_should_be_able_to_send_response_for_invalid_user() throws ExecutionException, InterruptedException {


        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        UserDao repositoryMock = mock(UserDao.class);

        when(repositoryMock.getUserByUserName(any(String.class))).
                thenReturn(CompletableFuture.completedFuture(Optional.empty()));

        // Test Service
        UserService userService = new UserService(repositoryMock, ecProvider);


        CompletableFuture<Optional<UserResource>> future = userService.getUserProfile("a@a.com")
                .thenApplyAsync(
                        data -> data

                ).toCompletableFuture();


        Optional<UserResource> response = future.get();

        Assert.assertEquals(future.isDone(), true);

        Assert.assertEquals(false, response.isPresent());

    }

}


