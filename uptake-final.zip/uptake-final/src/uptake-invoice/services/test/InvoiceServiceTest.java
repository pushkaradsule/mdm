import com.uptake.invoice.dataaccess.InvoiceDao;
import com.uptake.invoice.entities.Invoice;
import com.uptake.invoice.resources.InvoiceResource;
import com.uptake.invoice.services.InvoiceService;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import play.i18n.Lang;
import play.i18n.Langs;
import play.i18n.MessagesApi;
import play.libs.Json;
import play.libs.concurrent.HttpExecutionContext;

import javax.persistence.NoResultException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by apurvav on 27-07-2017.
 */
public class InvoiceServiceTest {

    @Test
    public void should_get_all_invoices() throws ExecutionException, InterruptedException, ParseException {

        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        InvoiceDao repositoryMock = mock(InvoiceDao.class);

        List<Invoice> listOfInvoices = new ArrayList<>();

        Invoice i1 = new Invoice();

        i1.setCustomerId(1L);
        i1.setCustomerNumber("IT8SDS");
        i1.setCustomerType("RVN");
        i1.setInvoiceType("LBR");
        i1.setInvoiceAmt(52651.22);
        i1.setInvoiceStatus("BILLED");
        i1.setInvoiceDate(new Date(2016, 12, 30));

        i1.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2016/12/31"));


        Invoice i2 = new Invoice();

        i2.setCustomerId(2L);
        i2.setCustomerNumber("DC0WTY");
        i2.setCustomerType("INT");
        i2.setInvoiceType("RNT");
        i2.setInvoiceAmt(-6833.70721);
        i2.setInvoiceStatus("PENDING");
        i2.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2015/07/31"));

        listOfInvoices.add(i1);
        listOfInvoices.add(i2);

        Map<String, String[]> queryMap = Collections.emptyMap();

        when(repositoryMock.getInvoiceData(queryMap)).
                thenReturn(CompletableFuture.completedFuture(listOfInvoices.stream()));

        // Test Service
        InvoiceService invoiceService = new InvoiceService(repositoryMock, ecProvider);

        CompletableFuture<Stream<InvoiceResource>> future = invoiceService.getInvoiceData(queryMap)
                .thenApplyAsync(
                        data -> data

                ).toCompletableFuture();


        List<InvoiceResource> output = future.get().collect(Collectors.toList());

        Assert.assertEquals(future.isDone(), true);
        Assert.assertEquals(output.size(), 2);

    }

    @Test
    public void should_get_invoices_in_date_range() throws ExecutionException, InterruptedException, ParseException {

        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        InvoiceDao repositoryMock = mock(InvoiceDao.class);

        List<Invoice> listOfInvoices = new ArrayList<>();

        Invoice i1 = new Invoice();

        i1.setCustomerId(1L);
        i1.setCustomerNumber("IT8SDS");
        i1.setCustomerType("RVN");
        i1.setInvoiceType("LBR");
        i1.setInvoiceAmt(52651.22);
        i1.setInvoiceStatus("BILLED");
        i1.setInvoiceDate(new Date(2016, 12, 30));

        i1.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2016/12/31"));


        Invoice i2 = new Invoice();

        i2.setCustomerId(2L);
        i2.setCustomerNumber("DC0WTY");
        i2.setCustomerType("INT");
        i2.setInvoiceType("RNT");
        i2.setInvoiceAmt(-6833.70721);
        i2.setInvoiceStatus("PENDING");
        i2.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2015/07/31"));

        listOfInvoices.add(i1);
        listOfInvoices.add(i2);

        Map<String, String[]> queryMap = new HashMap<>();
        queryMap.put("startDate", new String[]{"2016/07/01"});
        queryMap.put("endDate", new String[]{"2016/12/31"});

        Date startDate = new SimpleDateFormat("yyyy/MM/dd").parse(
                queryMap.get("startDate")[0]);
        Date endDate = new SimpleDateFormat("yyyy/MM/dd").parse(
                queryMap.get("endDate")[0]);


        when(repositoryMock.getInvoiceDataByRange(queryMap, startDate, endDate)).
                thenReturn(CompletableFuture.completedFuture(listOfInvoices.stream().filter(
                        invoice -> {
                            if (invoice.getInvoiceDate().compareTo(startDate) >= 0 && invoice.getInvoiceDate().compareTo(endDate) <= 0)
                                return true;
                            return false;
                        }
                )));

        // Test Service
        InvoiceService invoiceService = new InvoiceService(repositoryMock, ecProvider);

        CompletableFuture<Stream<InvoiceResource>> future = invoiceService.getInvoiceData(queryMap)
                .thenApplyAsync(
                        data -> data

                ).toCompletableFuture();


        List<InvoiceResource> output = future.get().collect(Collectors.toList());

        Assert.assertEquals(future.isDone(), true);
        Assert.assertEquals(output.size(), 1);

    }

    @Test
    public void should_get_invoices_with_invoice_status_billed() throws ExecutionException, InterruptedException, ParseException {

        final HttpExecutionContext ecProvider = new HttpExecutionContext(ForkJoinPool.commonPool());

        InvoiceDao repositoryMock = mock(InvoiceDao.class);

        List<Invoice> listOfInvoices = new ArrayList<>();

        Invoice i1 = new Invoice();

        i1.setCustomerId(1L);
        i1.setCustomerNumber("IT8SDS");
        i1.setCustomerType("RVN");
        i1.setInvoiceType("LBR");
        i1.setInvoiceAmt(52651.22);
        i1.setInvoiceStatus("BILLED");
        i1.setInvoiceDate(new Date(2016, 12, 30));

        i1.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2016/12/31"));


        Invoice i2 = new Invoice();

        i2.setCustomerId(2L);
        i2.setCustomerNumber("DC0WTY");
        i2.setCustomerType("INT");
        i2.setInvoiceType("RNT");
        i2.setInvoiceAmt(-6833.70721);
        i2.setInvoiceStatus("PENDING");
        i2.setInvoiceDate(new SimpleDateFormat("yyyy/MM/dd").parse("2015/07/31"));

        listOfInvoices.add(i1);
        listOfInvoices.add(i2);

        Map<String, String[]> queryMap = Collections.emptyMap();

        when(repositoryMock.getMonthToDateData(queryMap)).
                thenReturn(CompletableFuture.completedFuture(listOfInvoices.stream().filter(
                        invoice ->
                                invoice.getInvoiceStatus().equalsIgnoreCase("BILLED")
                )));

        // Test Service
        InvoiceService invoiceService = new InvoiceService(repositoryMock, ecProvider);

        CompletableFuture<Stream<InvoiceResource>> future = invoiceService.getMonthToDateData(queryMap)
                .thenApplyAsync(
                        data -> data

                ).toCompletableFuture();


        List<InvoiceResource> output = future.get().collect(Collectors.toList());

        Assert.assertEquals(future.isDone(), true);
        Assert.assertEquals(output.size(), 1);

    }

    public static <T> CompletableFuture<T> exceptionallyCompletedFuture(Throwable throwable) {
        final CompletableFuture<T> future = new CompletableFuture<>();
        future.completeExceptionally(throwable);
        return future;
    }

}
