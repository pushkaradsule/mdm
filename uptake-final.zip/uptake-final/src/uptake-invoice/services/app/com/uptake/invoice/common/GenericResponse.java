package com.uptake.invoice.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by apurvav on 17-07-2017.
 */
public class GenericResponse<T> {

    public Boolean isSuccess;
    public Boolean isPartialSuccess;
    private ArrayList<HashMap<String, String>> validationMessage;
    private ArrayList<HashMap<String, String>> errorMessage;
    private T Results;

    public GenericResponse()
    {
        validationMessage = new ArrayList<>();
        errorMessage = new ArrayList<>();
        isSuccess = false;
        isPartialSuccess = false;
    }

    public List<HashMap<String, String>> getValidationMessage() {
        return validationMessage;
    }

    public void addValidationMessage(String key, String value) {
        validationMessage.add(new HashMap<String, String>() {{
            put(key,value);
        }});
    }

    public List<HashMap<String, String>> getErrorMessage() {
        return errorMessage;
    }

    public void addErrorMessage(String key, String value) {
        errorMessage.add(new HashMap<String, String>() {{
            put(key,value);
        }});
    }

    public void addErrorMessage(UptakeMessages.ErrorMessages messages) {
        errorMessage.add(new HashMap<String, String>() {{
            put(messages.toString(),messages.getMessage());
        }});
    }

    public T getResults() {
        return Results;
    }

    public void setResults(T results) {
        Results = results;
    }
}
