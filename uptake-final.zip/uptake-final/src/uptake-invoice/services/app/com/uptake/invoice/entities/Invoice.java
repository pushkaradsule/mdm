package com.uptake.invoice.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "invoices")
public class Invoice implements Serializable {

    @Id
    @Column(name = "customerId")
    private Long customerId;

    @Column(name = "customerNumber")
    private String customerNumber;

    @Column(name = "customerType")
    private String customerType;

    @Column(name = "invoiceType")
    private String invoiceType;

    @Column(name = "invoiceAmt")
    private Double invoiceAmt;

    @Column(name = "invoiceStatus")
    private String invoiceStatus;

    @Column(name = "invoiceDate")
    @Temporal(TemporalType.DATE)
    private Date invoiceDate;

    @Transient
    private String month;

    @Transient
    private String year;

    @Transient
    private String quarter;

    @Transient
    private String title;

    public Invoice() {
    }

    public Invoice(String customerNumber, double invoiceAmt) {
        this.customerNumber = customerNumber;
        this.invoiceAmt = invoiceAmt;
    }

    public Invoice(String groupByString, double invoiceAmt, String groupBy) {

        switch (groupBy){
            case "month": {
                this.month = groupByString;
                break;
            }
            case "year": {
                this.year = groupByString;
                break;
            }
            case "quarter": {
                this.quarter = groupByString;
                break;
            }
            default: {
                this.title = groupByString;
                break;
            }
        }

        this.invoiceAmt = invoiceAmt;
    }

    public Invoice(long customerId, String customerNumber, String customerType, String invoiceType, double invoiceAmt, String invoiceStatus, Date invoiceDate) {
        this.customerId = customerId;
        this.customerNumber = customerNumber;
        this.customerType = customerType;
        this.invoiceType = invoiceType;
        this.invoiceAmt = invoiceAmt;
        this.invoiceStatus = invoiceStatus;
        this.invoiceDate = invoiceDate;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public Double getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(Double invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getQuarter() {
        return quarter;
    }

    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
