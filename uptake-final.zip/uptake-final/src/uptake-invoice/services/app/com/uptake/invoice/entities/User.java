package com.uptake.invoice.entities;

import play.data.validation.Constraints;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by apurvav on 17-07-2017.
 */

@NamedQueries({
        @NamedQuery(
                name = "User.checkUserByUserName",
                query = "select u from User u WHERE u.email = :email"
        )
})

@Entity
@Table(name = "users")
public class User implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer userId;

    @Constraints.Required(message = "password is mandaotory")
    private String email;

    @Column(name = "encrypted_password")
    @Constraints.Required(message = "password is mandaotory")
    private String password;

    @Column(name = "password_salt")
    private String passwordSalt;

    @Column(name = "first_name")
    @Constraints.Required(message = "first name is mandaotory")
    private String firstName;

    @Column(name = "last_name")
    @Constraints.Required(message = "last name is mandaotory")
    private String lastName;

    public User(String email,String password) {
        this.email = email;
        this.password = password;
    }

    public User(){

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getPasswordSalt() {
        return passwordSalt;
    }

    public void setPasswordSalt(String passwordSalt) {
        this.passwordSalt = passwordSalt;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
