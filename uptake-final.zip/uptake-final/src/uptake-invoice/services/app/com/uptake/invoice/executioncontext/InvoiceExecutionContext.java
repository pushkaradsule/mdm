package com.uptake.invoice.executioncontext;

import akka.actor.ActorSystem;
import play.libs.concurrent.CustomExecutionContext;

import javax.inject.Inject;

/**
 * Created by apurvav on 17-07-2017.
 */
public class InvoiceExecutionContext extends CustomExecutionContext {

    @Inject
    public InvoiceExecutionContext(ActorSystem actorSystem) {
        super(actorSystem, "invoice.repository");
    }
}
