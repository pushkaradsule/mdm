package com.uptake.invoice.dataaccess;

import com.uptake.invoice.entities.Invoice;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.stream.Stream;

/**
 * Created by apurvav on 17-07-2017.
 */
public interface InvoiceDao {
    CompletionStage<Stream<Invoice>> getRevenues();
    CompletionStage<Stream<Invoice>> getInvoiceData(Map<String, String[]> queryMap);
    CompletionStage<Stream<Invoice>> getInvoiceDataByRange(Map<String, String[]> queryMap, Date startDate, Date endDate);
    CompletionStage<Stream<Invoice>> getMonthToDateData(Map<String, String[]> queryMap);
    CompletionStage<Stream<Invoice>> getQuarterToDateData(Map<String, String[]> queryMap);
    CompletionStage<Stream<Invoice>> getYearToDateData(Map<String, String[]> queryMap);
}
