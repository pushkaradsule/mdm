package com.uptake.invoice.security;

import org.apache.commons.codec.binary.Base64;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

/**
 * Created by apurvav on 26-07-2017.
 */
public class Cryptographer {

    public static Boolean validateHashedPassword(String dbPassword, String inputPassword, String salt) {
        String inputHashPassword = generateHashedPassword(inputPassword, salt);

        if (inputHashPassword.equals(dbPassword))
            return true;
        return false;
    }

    public static String generateHashedPassword(String password, String salt) {
        String saltedPassword = salt + password;
        return generateHash(saltedPassword);
    }

    public static String generateHash(String input) {
        StringBuilder hash = new StringBuilder();

        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] hashedBytes = sha.digest(input.getBytes());
            char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                    'a', 'b', 'c', 'd', 'e', 'f'};
            for (int idx = 0; idx < hashedBytes.length; ++idx) {
                byte b = hashedBytes[idx];
                hash.append(digits[(b & 0xf0) >> 4]);
                hash.append(digits[b & 0x0f]);
            }
        } catch (NoSuchAlgorithmException e) {

        }

        return hash.toString();
    }

    public static String getNextSalt() {
        Random random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return byteToString(salt);
    }

    public static String byteToString(byte[] input) {
        return Base64.encodeBase64String(input);
    }
}