package com.uptake.invoice.services;

/**
 * Created by apurvav on 26-07-2017.
 */
public class UptakeService {

    private String CurrentUserId;

    public String getCurrentUserId() {
        return CurrentUserId;
    }

    public void setCurrentUserId(String currentUserId) {
        CurrentUserId = currentUserId;
    }
}
