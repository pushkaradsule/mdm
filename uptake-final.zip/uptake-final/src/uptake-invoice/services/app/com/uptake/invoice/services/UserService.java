package com.uptake.invoice.services;

import com.uptake.invoice.common.GenericResponse;
import com.uptake.invoice.common.UptakeMessages;
import com.uptake.invoice.dataaccess.UserDao;
import com.uptake.invoice.resources.UserResource;
import com.uptake.invoice.security.Cryptographer;
import play.libs.concurrent.HttpExecutionContext;

import javax.inject.Inject;
import java.util.Optional;
import java.util.concurrent.CompletionStage;

/**
 * Created by apurvav on 17-07-2017.
 */
public class UserService extends UptakeService{
    private final UserDao repository;
    private final HttpExecutionContext ec;

    @Inject
    public UserService(UserDao repository, HttpExecutionContext ec) {
        this.repository = repository;
        this.ec = ec;
    }

    public CompletionStage<Optional<UserResource>> getUserProfile(String userName) {
        return repository.getUserByUserName(userName)
                .thenApplyAsync(optionalData ->
                        optionalData.map(UserResource::new), ec.current());
    }

    public CompletionStage<GenericResponse<Object>> validateUserByUserNameAndPassword(String userName, String password) {

        GenericResponse<Object> response = new GenericResponse<>();


        return repository.getUserByUserName(userName).thenApplyAsync(user -> {

            if (user.isPresent() && Cryptographer.validateHashedPassword(user.get().getPassword(),
                    password, user.get().getPasswordSalt())) {
                response.setResults(true);
                response.isSuccess = true;

            } else {
                response.addErrorMessage(UptakeMessages.ErrorMessages.LOGIN_FAILED.toString(),
                        UptakeMessages.ErrorMessages.LOGIN_FAILED.getMessage());
            }

            return response;
        }, ec.current()).exceptionally(u -> {
            response.addErrorMessage(UptakeMessages.ErrorMessages.LOGIN_FAILED.toString(),
                    UptakeMessages.ErrorMessages.LOGIN_FAILED.getMessage());

            return response;
        });
    }
}
