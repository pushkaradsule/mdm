package com.uptake.invoice.resources;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uptake.invoice.entities.Invoice;

import java.util.Date;

/**
 * Created by apurvav on 27-07-2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvoiceResource {

    private Long customerId;
    private String customerNumber;
    private String customerType;
    private String invoiceType;
    private Double invoiceAmt;
    private String invoiceStatus;
    private Date invoiceDate;

    @JsonProperty("month")
    private String month;

    @JsonProperty("year")
    private String year;

    @JsonProperty("quarter")
    private String quarter;

    @JsonProperty("title")
    private String title;

    public InvoiceResource() {
    }

    public InvoiceResource(Invoice invoice) {
        this.customerId = invoice.getCustomerId();
        this.customerNumber = invoice.getCustomerNumber();
        this.customerType = invoice.getCustomerType();
        this.invoiceType = invoice.getInvoiceType();
        this.invoiceStatus = invoice.getInvoiceStatus();
        this.invoiceDate = invoice.getInvoiceDate();
        this.month = invoice.getMonth();
        this.quarter = invoice.getQuarter();
        this.year = invoice.getYear();
        this.title = invoice.getTitle();
        this.invoiceAmt = invoice.getInvoiceAmt();
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public Double getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(Double invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }
}
