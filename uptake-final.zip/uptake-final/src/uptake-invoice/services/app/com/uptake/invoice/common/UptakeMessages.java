package com.uptake.invoice.common;

/**
 * Created by apurvav on 17-07-2017.
 */
public class UptakeMessages {

    public enum  ErrorMessages {
        LOGIN_FAILED("Invalid user name or password"),
        INVALID_DATA("Invalid data"),
        MISSING_PARAMETERS("Missing parameter [name]"),
        UNAUTHORIZED_LOGIN("Unauthorized login"),
        ACCESS_DENIED("access denied");

        private String message;

        ErrorMessages(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public enum  ValidationMessage {
        LOGIN_FAILED("Invalid user name or password"),
        USER_ALREADY_EXIST("user already exist"),
        USER_NOT_FOUND("USER NOT FOUND");
        private String message;

        ValidationMessage(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
}
