package com.uptake.invoice.resources;

import com.uptake.invoice.entities.User;

import java.io.Serializable;

/**
 * Created by apurvav on 12-07-2017.
 */
public class UserResource implements Serializable{
    private String userName;
    private String password;

    private String firstName;
    private String lastName;
    private Integer userId;

    public UserResource() {
    }

    public UserResource(String username, String password) {
        this.userName = username;
        this.password = password;
    }

    public UserResource(User user) {
        this.setFirstName(user.getFirstName());
        this.setLastName(user.getLastName());
        this.setUserName(user.getEmail());
        this.setUserId(user.getUserId());

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String username) {
        this.userName = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
