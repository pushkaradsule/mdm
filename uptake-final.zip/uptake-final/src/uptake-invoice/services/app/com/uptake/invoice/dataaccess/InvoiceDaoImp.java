package com.uptake.invoice.dataaccess;

import com.uptake.invoice.entities.Invoice;
import com.uptake.invoice.executioncontext.InvoiceExecutionContext;
import net.jodah.failsafe.CircuitBreaker;
import net.jodah.failsafe.Failsafe;
import play.db.jpa.JPAApi;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import java.util.stream.Stream;

import static java.util.concurrent.CompletableFuture.supplyAsync;

@Singleton
public class InvoiceDaoImp implements InvoiceDao {

    private final JPAApi jpaApi;
    private final InvoiceExecutionContext ec;
    private final CircuitBreaker circuitBreaker = new CircuitBreaker()
            .withFailureThreshold(1)
            .withSuccessThreshold(3);

    @Inject
    public InvoiceDaoImp(JPAApi jpaApi, InvoiceExecutionContext ec) {
        this.jpaApi = jpaApi;
        this.ec = ec;
    }

    @Override
    public CompletionStage<Stream<Invoice>> getRevenues() {
        return supplyAsync(() -> wrap(em ->
                Failsafe.with(circuitBreaker).get(() -> getRevenues(em))), ec);
    }

    @Override
    public CompletionStage<Stream<Invoice>> getInvoiceData(Map<String, String[]> queryMap) {
        return supplyAsync(() -> wrap(em ->
                Failsafe.with(circuitBreaker).get(() -> getInvoices(em, queryMap))), ec);
    }

    @Override
    public CompletionStage<Stream<Invoice>> getInvoiceDataByRange(Map<String, String[]> queryMap, Date startDate, Date endDate) {

        return supplyAsync(() -> wrap(em -> Failsafe.with(circuitBreaker).get(()
                -> getByDateRange(em, queryMap, startDate, endDate))), ec);

    }

    @Override
    public CompletionStage<Stream<Invoice>> getMonthToDateData(Map<String, String[]> queryMap) {
        return supplyAsync(() -> wrap(em ->
                Failsafe.with(circuitBreaker).get(() -> getMonthToDate(em, queryMap))), ec);
    }

    @Override
    public CompletionStage<Stream<Invoice>> getQuarterToDateData(Map<String, String[]> queryMap) {
        return supplyAsync(() -> wrap(em ->
                Failsafe.with(circuitBreaker).get(() -> getQuarterToDate(em, queryMap))), ec);
    }

    @Override
    public CompletionStage<Stream<Invoice>> getYearToDateData(Map<String, String[]> queryMap) {
        return supplyAsync(() -> wrap(em ->
                Failsafe.with(circuitBreaker).get(() -> getYearToDate(em, queryMap))), ec);
    }

    private Stream<Invoice> getRevenues(EntityManager em){

        List<Invoice> invoices = new ArrayList<>();

        StringBuilder queryString = new StringBuilder();

        queryString.append("select 'Month-to-Date' ,sum(invoiceAmt) from invoices where month(invoiceDate)=month('2016-12-30') and year(invoiceDate)=year('2016-12-30') ");
        queryString.append("union select 'Quarter-to-Date',sum(invoiceAmt) from invoices where quarter(invoiceDate)=quarter('2016-12-30') and year(invoiceDate)=year('2016-12-30') ");
        queryString.append("union select 'Year-to-Date',sum(invoiceAmt) from invoices where year(invoiceDate)=year('2016-12-30')");

        Query query = em.createNativeQuery(queryString.toString());

        List<Object[]> invoiceList = query.getResultList();

        for (Object[] result : invoiceList) {
            String title = (String) result[0];
            double amount = ((Number) result[1]).doubleValue();
            invoices.add(new Invoice(title, amount, "title"));
        }

        return invoices.stream();
    }

    private Stream<Invoice> getInvoices(EntityManager em, Map<String, String[]> queryMap) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);

        List<Predicate> predicates = new ArrayList<>();

        predicates.add(getFilterPredicates(builder, root, queryMap));

        criteriaQuery = getGroupByCustomerNumberQuery(builder, root, criteriaQuery, queryMap);

        criteriaQuery.where(predicates.toArray(new Predicate[]{}));

        TypedQuery<Invoice> query = em.createQuery(criteriaQuery);

        return query.getResultList().stream();
    }

    private Stream<Invoice> getByDateRange(EntityManager em, Map<String, String[]> queryMap,
                                           Date fromDate,
                                           Date toDate) throws SQLException, ParseException {


        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);
        List<Predicate> predicates = new ArrayList<>();

        predicates.add(builder.between(root.get("invoiceDate"), fromDate, toDate));

        predicates.add(getFilterPredicates(builder, root, queryMap));

        criteriaQuery = getGroupByCustomerNumberQuery(builder, root, criteriaQuery, queryMap);

        criteriaQuery.where(predicates.toArray(new Predicate[]{}));

        TypedQuery<Invoice> query = em.createQuery(criteriaQuery);

        return query.getResultList().stream();
    }

    private Predicate getFilterPredicates(CriteriaBuilder builder,
                                       Root<?> root,
                                       Map<String, String[]> queryMap) {

        Expression<String> invoiceStatusExp = root.get("invoiceStatus").as(String.class);
        Expression<String> customerTypeExp = root.get("customerType").as(String.class);

        String[] customerTypeFilter = queryMap.getOrDefault("customertype", new String[0]);
        String[] invoiceStatusFilter = queryMap.getOrDefault("invoicestatus", new String[0]);


        if (invoiceStatusFilter.length > 0) {
            return invoiceStatusExp.in(
                    new ArrayList<>(Arrays.asList(
                            invoiceStatusFilter[0].toUpperCase()
                                    .split(","))));
        }

        if (customerTypeFilter.length > 0) {
            return customerTypeExp.in(
                    new ArrayList<>(Arrays.asList(
                            customerTypeFilter[0].toUpperCase()
                                    .split(","))));
        }

        return builder.isTrue(builder.literal(true));
    }

    private CriteriaQuery<Invoice> getGroupByCustomerNumberQuery(CriteriaBuilder builder,
                                                                 Root<Invoice> root,
                                                                 CriteriaQuery<Invoice> criteriaQuery,
                                                                 Map<String, String[]> queryMap) {

        String[] groupBy = queryMap.getOrDefault("group-by", new String[0]);

        if (groupBy.length > 0) {
            String groupByFilter = groupBy[0];
            switch (groupByFilter.toUpperCase()) {
                case "MONTH": {
                    criteriaQuery = getMonthGroupBy(builder, criteriaQuery, root);
                    break;
                }
                case "QUARTER": {
                    criteriaQuery = getQuarterGroupBy(builder, criteriaQuery, root);
                    break;
                }
                case "YEAR": {
                    criteriaQuery = getYearGroupBy(builder, criteriaQuery, root);
                    break;
                }
                default: {
                    Expression<String> groupByExp = root.get("customerNumber").as(String.class);
                    Expression<Double> invoiceAmtExp = builder.sum(root.get("invoiceAmt").as(Double.class));
                    criteriaQuery.multiselect(groupByExp, invoiceAmtExp);
                    criteriaQuery.groupBy(groupByExp);
                }
            }
        }
        return criteriaQuery;
    }

    private CriteriaQuery<Invoice> getMonthGroupBy(CriteriaBuilder builder, CriteriaQuery<Invoice> criteriaQuery, Root<Invoice> root) {
        Expression<String> monthLiteral = builder.literal("month");

        Expression<String> select_date_format = builder.function("DATE_FORMAT", String.class, root.<Date>get("invoiceDate"), builder.literal("%M - %Y"));
        Expression<Double> invoiceAmtExp = builder.sum(root.get("invoiceAmt").as(Double.class));

        Expression<String> groupByMonth = getDateFormatExp("MONTH", builder, root);
        Expression<String> groupByYear = getDateFormatExp("YEAR", builder, root );

        Expression<String> month = builder.concat(groupByMonth, groupByYear);

        CriteriaQuery<Invoice> select = criteriaQuery.multiselect(select_date_format, invoiceAmtExp, monthLiteral);
        criteriaQuery.groupBy(month);

        List<Order> orderList = new ArrayList<>();

        orderList.add(builder.desc(groupByYear));
        orderList.add(builder.asc(groupByMonth));

        criteriaQuery.orderBy(orderList);

        return select;
    }

    private Expression<String> getDateFormatExp(String format, CriteriaBuilder builder, Root<Invoice> root){
        return builder.function(format, String.class, root.get("invoiceDate").as(Date.class));
    }

    private CriteriaQuery<Invoice> getQuarterGroupBy(CriteriaBuilder builder, CriteriaQuery<Invoice> criteriaQuery, Root<Invoice> root) {
        Expression<String> quarterLiteral = builder.literal("quarter");

        Expression<String> quarter_format = builder.concat("Q", builder.function("QUARTER", String.class, root.<Date>get("invoiceDate")));
        Expression<String> year_format = builder.concat(builder.concat("(", builder.function("YEAR", String.class, root.<Date>get("invoiceDate"))), ")");
        Expression<String> select_date_format = builder.function("CONCAT", String.class, quarter_format, year_format);

        Expression<Double> invoiceAmtExp = builder.sum(root.get("invoiceAmt").as(Double.class));

        Expression<String> groupByMonth = getDateFormatExp("QUARTER", builder, root);
        Expression<String> groupByYear = getDateFormatExp("YEAR", builder, root );

        Expression<String> month = builder.concat(groupByMonth, groupByYear);

        CriteriaQuery<Invoice> select = criteriaQuery.multiselect(select_date_format, invoiceAmtExp, quarterLiteral);

        criteriaQuery.groupBy(month);

        List<Order> orderList = new ArrayList<>();
        orderList.add(builder.desc(groupByYear));
        orderList.add(builder.asc(groupByMonth));

        criteriaQuery.orderBy(orderList);

        return select;
    }

    private CriteriaQuery<Invoice> getYearGroupBy(CriteriaBuilder builder, CriteriaQuery<Invoice> criteriaQuery, Root<Invoice> root) {
        Expression<String> yearLiteral = builder.literal("year");

        Expression<String> groupByYear = getDateFormatExp("YEAR", builder, root );

        Expression<String> select_date_format = builder.function("STR", String.class, groupByYear);
        Expression<Double> invoiceAmtExp = builder.sum(root.get("invoiceAmt").as(Double.class));

        CriteriaQuery<Invoice> select = criteriaQuery.multiselect(select_date_format, invoiceAmtExp, yearLiteral);
        criteriaQuery.groupBy(groupByYear);

        criteriaQuery.orderBy(builder.desc(groupByYear));
        return select;
    }

    private Stream<Invoice> getMonthToDate(EntityManager em, Map<String, String[]> queryMap) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);
        List<Predicate> predicates = new ArrayList<>();

        Expression<String> currentDateLiteral = builder.literal("2016-12-31");

        Expression<String> invoiceMonth = getDateFormatExp("MONTH", builder, root);
        Expression<String> currentMonth = builder.function("MONTH", String.class, currentDateLiteral);

        Expression<String> invoiceYear = getDateFormatExp("YEAR", builder, root);
        Expression<String> currentYear = builder.function("YEAR", String.class, currentDateLiteral);

        predicates.add(builder.and(builder.equal(invoiceMonth, currentMonth), builder.equal(invoiceYear, currentYear)));

        predicates.add(getFilterPredicates(builder, root, queryMap));

        criteriaQuery = getGroupByCustomerNumberQuery(builder, root, criteriaQuery, queryMap);

        criteriaQuery.where(predicates.toArray(new Predicate[]{}));

        TypedQuery<Invoice> query = em.createQuery(criteriaQuery);

        return query.getResultList().stream();
    }

    private Stream<Invoice> getQuarterToDate(EntityManager em, Map<String, String[]> queryMap) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);

        List<Predicate> predicates = new ArrayList<>();

        Expression<String> currentDateLiteral = builder.literal("2016-12-31");

        Expression<String> invoiceQuarter = getDateFormatExp("QUARTER", builder, root);
        Expression<String> currentQuarter = builder.function("QUARTER", String.class, currentDateLiteral);

        Expression<String> invoiceYear = getDateFormatExp("YEAR", builder, root);
        Expression<String> currentYear = builder.function("YEAR", String.class, currentDateLiteral);

        predicates.add(builder.and(builder.equal(invoiceQuarter, currentQuarter), builder.equal(invoiceYear, currentYear)));

        predicates.add(getFilterPredicates(builder, root, queryMap));

        criteriaQuery = getGroupByCustomerNumberQuery(builder, root, criteriaQuery, queryMap);

        criteriaQuery.where(predicates.toArray(new Predicate[]{}));

        TypedQuery<Invoice> query = em.createQuery(criteriaQuery);


        return query.getResultList().stream();
    }

    private Stream<Invoice> getYearToDate(EntityManager em, Map<String, String[]> queryMap) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);
        List<Predicate> predicates = new ArrayList<>();

        Expression<String> currentDateLiteral = builder.literal("2016-12-31");

        Expression<String> invoiceYear = getDateFormatExp("YEAR", builder, root);
        Expression<String> currentYear = builder.function("YEAR", String.class, currentDateLiteral);

        predicates.add(builder.equal(invoiceYear, currentYear));

        predicates.add(getFilterPredicates(builder, root, queryMap));

        criteriaQuery = getGroupByCustomerNumberQuery(builder, root, criteriaQuery, queryMap);

        criteriaQuery.where(predicates.toArray(new Predicate[]{}));

        TypedQuery<Invoice> query = em.createQuery(criteriaQuery);

        return query.getResultList().stream();
    }

    private <T> T wrap(Function<EntityManager, T> function) {
        return jpaApi.withTransaction(function);
    }

}
