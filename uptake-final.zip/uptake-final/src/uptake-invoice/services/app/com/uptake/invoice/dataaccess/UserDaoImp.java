package com.uptake.invoice.dataaccess;

import com.uptake.invoice.entities.User;
import com.uptake.invoice.executioncontext.UserExecutionContext;
import net.jodah.failsafe.CircuitBreaker;
import net.jodah.failsafe.Failsafe;

import play.db.jpa.JPAApi;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityManager;

import java.sql.SQLException;
import java.util.Optional;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

import static java.util.concurrent.CompletableFuture.supplyAsync;

@Singleton
public class UserDaoImp implements UserDao {

    private final JPAApi jpaApi;
    private final UserExecutionContext ec;
    private final CircuitBreaker circuitBreaker = new CircuitBreaker()
            .withFailureThreshold(1)
            .withSuccessThreshold(3);

    @Inject
    public UserDaoImp(JPAApi jpaApi, UserExecutionContext ec) {
        this.jpaApi = jpaApi;
        this.ec = ec;
    }

    public CompletionStage<Optional<User>> getUserByUserName(String userName) {
        return supplyAsync(() ->
                wrap(em -> Failsafe.with(circuitBreaker).get(() -> lookup(em, userName))), ec);
    }

    private <T> T wrap(Function<EntityManager, T> function) {
        return jpaApi.withTransaction(function);
    }

    private Optional<User> lookup(EntityManager em, String id) throws SQLException {

        User user = (User) em.createNamedQuery("User.checkUserByUserName")
                .setParameter("email", id).getSingleResult();

        return Optional.ofNullable(user);
    }

}
