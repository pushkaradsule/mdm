package com.uptake.invoice.services;

import com.uptake.invoice.dataaccess.InvoiceDao;
import com.uptake.invoice.resources.InvoiceResource;
import play.libs.concurrent.HttpExecutionContext;

import javax.inject.Inject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletionStage;
import java.util.stream.Stream;

/**
 * Created by apurvav on 17-07-2017.
 */
public class InvoiceService {
    private final InvoiceDao repository;
    private final HttpExecutionContext ec;

    @Inject
    public InvoiceService(InvoiceDao repository, HttpExecutionContext ec) {
        this.repository = repository;
        this.ec = ec;
    }

    public CompletionStage<Stream<InvoiceResource>> getInvoiceData(Map<String, String[]> queryMap) {

        Date fromDate = null;
        Date toDate = null;

        if (queryMap.containsKey("startDate") && queryMap.containsKey("endDate")) {
            String startDate = queryMap.get("startDate")[0];
            String endDate = queryMap.get("endDate")[0];

            try {
                fromDate = new SimpleDateFormat("yyyy/MM/dd").parse(startDate);
                toDate = new SimpleDateFormat("yyyy/MM/dd").parse(endDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return this.repository.getInvoiceDataByRange(queryMap, fromDate, toDate)
                    .thenApplyAsync(productDataStream ->
                            productDataStream.map(InvoiceResource::new), ec.current());
        }

        return this.repository.getInvoiceData(queryMap)
                .thenApplyAsync(productDataStream ->
                        productDataStream.map(InvoiceResource::new), ec.current());

    }

    public CompletionStage<Stream<InvoiceResource>> getDashboardData() {

        return this.repository.getRevenues()
                .thenApplyAsync(productDataStream ->
                        productDataStream.map(InvoiceResource::new), ec.current());
    }

    public CompletionStage<Stream<InvoiceResource>> getMonthToDateData(Map<String, String[]> queryMap) {

        return this.repository.getMonthToDateData(queryMap)
                .thenApplyAsync(productDataStream ->
                        productDataStream.map(InvoiceResource::new), ec.current());
    }

    public CompletionStage<Stream<InvoiceResource>> getQuarterToDateData(Map<String, String[]> queryMap) {

        return this.repository.getQuarterToDateData(queryMap)
                .thenApplyAsync(productDataStream ->
                        productDataStream.map(InvoiceResource::new), ec.current());
    }

    public CompletionStage<Stream<InvoiceResource>> getYearToDateData(Map<String, String[]> queryMap) {

        return this.repository.getYearToDateData(queryMap)
                .thenApplyAsync(productDataStream ->
                        productDataStream.map(InvoiceResource::new), ec.current());
    }

}
