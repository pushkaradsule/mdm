package com.uptake.invoice.dataaccess;

import com.uptake.invoice.entities.User;

import java.util.Optional;
import java.util.concurrent.CompletionStage;

/**
 * Created by apurvav on 17-07-2017.
 */
public interface UserDao {
    CompletionStage<Optional<User>> getUserByUserName(String userName);
}
