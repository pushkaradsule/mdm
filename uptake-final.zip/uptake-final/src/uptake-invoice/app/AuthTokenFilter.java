import akka.stream.Materializer;
import com.uptake.invoice.common.GenericResponse;
import com.uptake.invoice.common.UptakeMessages;
import com.uptake.invoice.security.AuthUtils;
import play.libs.Json;
import play.mvc.Filter;
import play.mvc.Http;
import play.mvc.Result;

import javax.inject.Inject;
import java.text.ParseException;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

import static play.mvc.Http.Status.UNAUTHORIZED;
import static play.mvc.Results.status;

/**
 * Created by apurvav on 17-07-2017.
 */
public class AuthTokenFilter extends Filter {

    private final AuthUtils authUtils;

    @Inject
    public AuthTokenFilter(Materializer mat, AuthUtils authUtils) {
        super(mat);
        this.authUtils = authUtils;
    }


    @Override
    public CompletionStage<Result> apply(Function<Http.RequestHeader,
            CompletionStage<Result>> nextFilter,
                                         Http.RequestHeader requestHeader) {


        if (!requestHeader.tags().getOrDefault("ROUTE_COMMENTS", "")
                .contains("NOAUTH")) {

            Boolean valid = checkAuthentication(requestHeader);

            if (!valid) {
                GenericResponse<Object> errorResponse = new GenericResponse<>();
                errorResponse.isSuccess = false;
                errorResponse.addErrorMessage(UptakeMessages.ErrorMessages.UNAUTHORIZED_LOGIN.toString(),
                        UptakeMessages.ErrorMessages.UNAUTHORIZED_LOGIN.getMessage());
                return CompletableFuture.completedFuture(status(UNAUTHORIZED, Json.toJson(errorResponse)));
            }
        }
        
        return nextFilter.apply(requestHeader).thenApply(result -> result);

    }

    private Boolean checkAuthentication(Http.RequestHeader requestHeader) {
        try {
            if (!requestHeader.getHeaders().get(AuthUtils.AUTH_HEADER_KEY).isPresent()) return false;
            Optional<String> token = getTokenFromHeader(requestHeader.getHeaders().get(AuthUtils.AUTH_HEADER_KEY).get());

            if (token.isPresent()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private Optional<String> getTokenFromHeader(String authToken) throws ParseException {
        return authUtils.getSubject(Optional.ofNullable(authToken));
    }
}
