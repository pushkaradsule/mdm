package com.uptake.invoice.controllers;

import com.uptake.invoice.resources.InvoiceResource;
import com.uptake.invoice.security.AuthUtils;
import com.uptake.invoice.services.InvoiceService;
import play.libs.Json;
import play.libs.concurrent.HttpExecutionContext;
import play.mvc.Result;

import javax.inject.Inject;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

/**
 * Created by apurvav on 26-07-2017.
 */
public class InvoiceController extends BaseController {

    private HttpExecutionContext ec;
    private final InvoiceService invoiceService;

    @Inject
    public InvoiceController(HttpExecutionContext ec,
                             final AuthUtils authUtils,
                             InvoiceService invoiceService) throws ParseException {
        super(authUtils);
        this.ec = ec;
        this.invoiceService = invoiceService;
    }

    public CompletionStage<Result> getDashBoardData() {

        return invoiceService.getDashboardData()
                .thenApplyAsync(invoices -> {
                    final List<InvoiceResource> invoiceList =
                            invoices.collect(Collectors.toList());

                    return ok(Json.toJson(invoiceList));
                }, ec.current());
    }

    public CompletionStage<Result> getInvoiceData() {

        Map<String, String[]> queryMap = request().queryString();

        return invoiceService.getInvoiceData(queryMap)
                .thenApplyAsync(invoices -> {
                    final List<InvoiceResource> invoiceList =
                            invoices.collect(Collectors.toList());

                    return ok(Json.toJson(invoiceList));
                }, ec.current());
    }

    public CompletionStage<Result> getMonthToDateData() {

        Map<String, String[]> queryMap = request().queryString();

        return invoiceService.getMonthToDateData(queryMap)
                .thenApplyAsync(invoices -> {
                    final List<InvoiceResource> invoiceList =
                            invoices.collect(Collectors.toList());

                    return ok(Json.toJson(invoiceList));
                }, ec.current());
    }

    public CompletionStage<Result> getQuarterToDateData() {

        Map<String, String[]> queryMap = request().queryString();

        return invoiceService.getQuarterToDateData(queryMap)
                .thenApplyAsync(invoices -> {
                    final List<InvoiceResource> invoiceList =
                            invoices.collect(Collectors.toList());

                    return ok(Json.toJson(invoiceList));
                }, ec.current());
    }

    public CompletionStage<Result> getYearToDateData() {

        Map<String, String[]> queryMap = request().queryString();

        return invoiceService.getYearToDateData(queryMap)
                .thenApplyAsync(invoices -> {
                    final List<InvoiceResource> invoiceList =
                            invoices.collect(Collectors.toList());

                    return ok(Json.toJson(invoiceList));
                }, ec.current());
    }

}
