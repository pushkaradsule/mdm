package com.uptake.invoice.security;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.typesafe.config.Config;
import org.joda.time.DateTime;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.text.ParseException;
import java.util.Date;
import java.util.Optional;

/**
 * Created by apurvav on 17-07-2017.
 */
@Singleton
public class AuthUtils {

    private final Config config;
    private static String TOKEN_SECRET = "a0a2abd8-6162-41c3-83d6-1cf559b46afc";
    private static final JWSHeader JWT_HEADER = new JWSHeader(JWSAlgorithm.HS256);
    public static final String AUTH_HEADER_KEY = "Authorization";

    @Inject
    public AuthUtils(Config config) {
        this.config = config;
        TOKEN_SECRET = this.config.getString("play.http.secret.key");
    }

    public Optional<String> getSubject(Optional<String> authHeader) throws ParseException {

        if (authHeader.isPresent()) {
            try {

                JWSVerifier verifier = new MACVerifier(TOKEN_SECRET);
                SignedJWT signedJWT = decodeToken(authHeader.get());

                if (signedJWT.verify(verifier) &&
                        new Date().before(signedJWT.getJWTClaimsSet().getExpirationTime())) {
                    return Optional.of(signedJWT.getJWTClaimsSet().getSubject());
                } else {

                    return Optional.empty();
                }

            } catch (JOSEException ex) {

                return Optional.empty();
            }

        }
        return Optional.empty();
    }

    private SignedJWT decodeToken(String authHeader) throws ParseException {
        return SignedJWT.parse(getSerializedToken(authHeader));
    }

    public Token createToken(String host, String sub) throws JOSEException {

        Integer expiryTime = config.getInt("api.token.expiry.minutes");

        JWTClaimsSet claim = new JWTClaimsSet.Builder()
                .subject(sub)
                .issuer(host)
                .issueTime(DateTime.now().toDate())
                .expirationTime(DateTime.now().plusMinutes(expiryTime).toDate())
                .build();

        JWSSigner signer = new MACSigner(TOKEN_SECRET);
        SignedJWT jwt = new SignedJWT(JWT_HEADER, claim);
        jwt.sign(signer);

        return new Token(jwt.serialize());
    }

    private String getSerializedToken(String authHeader) {
        return authHeader;
    }

}
