package com.uptake.invoice.security;

/**
 * Created by apurvav on 17-07-2017.
 */
public class Token {
    private String token;

    public Token(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}
