package com.uptake.invoice.controllers;

import com.uptake.invoice.security.AuthUtils;
import play.mvc.Controller;

import java.text.ParseException;
import java.util.Optional;

/**
 * Created by apurvav on 26-07-2017.
 */
public class BaseController extends Controller {

    protected final AuthUtils authUtils;

    public BaseController(AuthUtils authUtils) {
        this.authUtils = authUtils;
    }

    public Optional<String> getAuthUserID() throws ParseException {
        return authUtils.getSubject(request().header(AuthUtils.AUTH_HEADER_KEY));

    }
}
