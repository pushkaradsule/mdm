package com.uptake.invoice.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.nimbusds.jose.JOSEException;
import com.uptake.invoice.common.GenericResponse;
import com.uptake.invoice.common.UptakeMessages;
import com.uptake.invoice.resources.UserResource;
import com.uptake.invoice.security.AuthUtils;
import com.uptake.invoice.services.UserService;
import play.libs.Json;
import play.libs.concurrent.HttpExecutionContext;
import play.mvc.Result;
import javax.inject.Inject;
import java.text.ParseException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;


/**
 * Created by apurvav on 12-07-2017.
 */
public class ProfileController extends BaseController{

    private HttpExecutionContext ec;
    private final UserService userService;

    @Inject
    public ProfileController(HttpExecutionContext ec,
                             final AuthUtils authUtils,
                             UserService userService) throws ParseException {
        super(authUtils);
        this.ec = ec;
        this.userService = userService;
    }

    public CompletionStage<Result> getProfile() throws ParseException {
        return userService.getUserProfile(this.getAuthUserID().get()).thenApplyAsync(optionalResource -> {
            return optionalResource.map(resource ->
                    ok(Json.toJson(resource))
            ).orElseGet(() ->
                    notFound()
            );
        }, ec.current());
    }

    public CompletionStage<Result> login() throws JOSEException {


        JsonNode json = request().body().asJson();
        GenericResponse<Object> loginServiceResponse = new GenericResponse<Object>();
        loginServiceResponse.isSuccess = false;

        final UserResource user = Json.fromJson(json, UserResource.class);

        if (json == null || user == null) {
            loginServiceResponse.addErrorMessage(UptakeMessages.ErrorMessages.MISSING_PARAMETERS.toString(),
                    UptakeMessages.ErrorMessages.MISSING_PARAMETERS.getMessage());
            return CompletableFuture.completedFuture(badRequest());
        }

        return userService.validateUserByUserNameAndPassword(user.getUserName(), user.getPassword())
                .thenApplyAsync(data -> {
                    if (data.isSuccess) {
                        try {
                            data.setResults(authUtils.createToken(request().remoteAddress(), user.getUserName()));
                        } catch (JOSEException e) {
                            e.printStackTrace();
                        }
                        return ok(Json.toJson(data));
                    } else {
                        return status(UNAUTHORIZED, Json.toJson(data));
                    }
                }, ec.current());
    }
}
