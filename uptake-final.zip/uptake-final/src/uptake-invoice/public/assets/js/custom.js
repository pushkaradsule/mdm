jQuery('document').ready(function() {	

	
	// Slide Nav
	jQuery('.button-collapse').on('click', function(e) {
		e.preventDefault();
		jQuery(this).find('i').toggleClass('icon-toggle').toggleClass('icon-burger');
		jQuery('#navSidebar').toggleClass('open');
		jQuery('html').toggleClass('open-nav');
	});
	jQuery('.close-button').on('click', function(e) {
		e.preventDefault();
		jQuery('#navSidebar').removeClass('open');
		jQuery('html').removeClass('open-nav');
		jQuery('.button-collapse i').removeClass('icon-burger').addClass('icon-toggle')
	});
	
	/* Chart */
	$(function () {
				
		var data = [
			{
				value: 150,
				color:"#0653ab",
				highlight: "#207ee1",
				label: "Sales"
			},
			{
				value: 170,
				color: "#1f7ddb",
				highlight: "#1f7ddb",
				label: "Rental"
			},
			{
				value: 60,
				color: "#68acfa",
				highlight: "#68acfa",
				label: "Labor"
			},
			{
				value: 100,
				color: "#cccccc",
				highlight: "#cccccc",
				label: "Parts"
			}
		]		
	   	
		var option = {
			responsive: true,
			animationEasing: "easeOutQuart",
			maintainAspectRatio: false,

		};
		   
		// Get the context of the canvas element we want to select
		var ct = document.getElementById("myChart");
		if (ct != null) {
			var ctx = document.getElementById("myChart").getContext('2d');
			var myDoughnutChart = new Chart(ctx).Doughnut(data,option);
		}
		else {
			return false;
		}
	});
	

});


	