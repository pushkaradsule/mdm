import { TempPage } from './app.po';

describe('ui-starter', () => {
  let page: TempPage;

  beforeEach(() => {
    page = new TempPage();
  });

});
