import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import {API_ENDPOINT} from "./app/shared/environment.settings";

if (environment.production) {
  enableProdMode();
}

if (environment.cordova) {
 // API_ENDPOINT = environment.apiUrl;
}

platformBrowserDynamic().bootstrapModule(AppModule);
