import {Component} from '@angular/core'
import {MdDialogRef} from '@angular/material';

@Component({
  selector: 'filterby-sheet',
  templateUrl: './filterbysheet.component.html',
  styles: ['./filterbysheet.component.scss']
})

export class FilterBySheetComponent {
  selectedFilterOptions = [];
  isSelectAllOptionChecked: boolean = false;

  invoiceTypesFilter = [];
  customerTypesFilter = [];
  statusTypesFilter = [];
  filterArray = []


  constructor(private dialogRef: MdDialogRef<FilterBySheetComponent>) {

  }

  setFilterArray(value) {
    let index = this.filterArray.indexOf(value);
    if (index == -1)
      this.filterArray.push(value);
    else
      this.filterArray.splice(index, 1);

    if (this.filterArray.length == this.selectedFilterOptions.length)
      this.isSelectAllOptionChecked = true;
    else
      this.isSelectAllOptionChecked = false;
  }

  onSelectAll() {
    if (!this.isSelectAllOptionChecked) {
      this.filterArray = [];
      for (let i = 0; i < this.selectedFilterOptions.length; i++)
        this.filterArray.push(this.selectedFilterOptions[i].value)
    }
    else
      this.filterArray = [];
  }

  setInvoiceTypeArray(value) {
    let index = this.invoiceTypesFilter.indexOf(value);
    if (index == -1)
      this.invoiceTypesFilter.push(value);
    else
      this.invoiceTypesFilter.splice(index, 1);
  }

  setCustomerTypeArray(value) {

    let index = this.customerTypesFilter.indexOf(value);
    if (index == -1)
      this.customerTypesFilter.push(value);
    else
      this.customerTypesFilter.splice(index, 1);
  }

  setStatusTypeArray(value) {
    let index = this.statusTypesFilter.indexOf(value);
    if (index == -1)
      this.statusTypesFilter.push(value);
    else
      this.statusTypesFilter.splice(index, 1);
  }

}
