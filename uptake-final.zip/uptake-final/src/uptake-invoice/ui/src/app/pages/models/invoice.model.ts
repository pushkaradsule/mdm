export interface Invoice {
    customerId: number;
    customerNumber: string;
    customerType: string;
    invoiceType: string;
    invoiceAmt: string;
    invoiceStatus: string;
    invoiceDate: Date;
    month: string;
    quarter: string;
    year: string;
    title: string;

}
