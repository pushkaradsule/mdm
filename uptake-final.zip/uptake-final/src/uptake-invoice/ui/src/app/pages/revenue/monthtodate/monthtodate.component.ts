import {Component, ViewChild} from '@angular/core'
import {Router} from '@angular/router';
import {MdDialog, MdDialogConfig} from '@angular/material';
import {FilterBySheetComponent} from '../../filterbysheet/filterbysheet.component'
import {ActionSheetComponent} from '../../actionsheet/actionsheet.component'
import {Invoice} from '../../models/invoice.model'
import {AppService} from '../../../app.service';
import * as Constants from '../../../shared/constants'
import {MonthToDateService} from '../../../services/monthtodate.service'
import {InvoiceService} from '../../../services/invoices.service'
import {PieChartComponent} from "../../pie-chart/pie-chart.component";
import {BaseClass} from '../../../shared/base.class'
import {DialogBoxComponent} from '../dialogbox/dialogbox.component'
import {mobiscroll} from '../../../app.module.ts';

@Component({
  selector: 'monthtodate',
  templateUrl: './monthtodate.component.html',
  styles: ['./monthtodate.component.scss']
})

export class MonthToDateComponent extends BaseClass {

  customerData: Invoice[] = [];
  revenueData: number[] = [];
  pieData = Constants.PIE_DATA;
  dialogRef: any;
  selectedFilterOptions = [];
  filterArray = [];
  filteredBy: string;
  fromDate: Date;
  toDate: Date;
  isDateRangeSelected: boolean = false;
  @ViewChild(PieChartComponent) pieChartComponent: PieChartComponent;
  invoice_names = Constants.INVOICE_NAMES;
  total_revenue: number = 0;
  hideFilterButton: boolean = false;

  range: Array<Date> = [];
  rangeSettings: {}

  constructor(private router: Router,
              public dialog: MdDialog,
              private appService: AppService,
              private monthToDateService: MonthToDateService,
              private invoiceService: InvoiceService) {
    super();
    this.appService.getState().pageFooter = true;
    let that =this;
    this.rangeSettings = {
      theme: 'uptake-light',
      display: 'bottom',
      setText: 'Filter',
      onSet : function(event, inst){
        that.fromDate = inst.getVal()[0];
        that.toDate = inst.getVal()[1];
        that.searchInvoiceBetweenGivenRange();
      }
    };
  }

  ngOnInit() {
    this.filteredBy = "INVOICE";
    this.selectedFilterOptions = Constants.STATUS_TYPES;
    this.getInvoiceDataByMonth();
  }

  getInvoiceDataByMonth() {
    this.monthToDateService.getInvoiceDataByMonth()
      .subscribe((data) => {
        this.customerData = data;
        this.calculateRevenuePerInvoiceType(this.customerData)
      })
  }

  searchInvoiceBetweenGivenRange() {
      this.filterArray = [];
      this.getInvoiceDataBetweenDateRange();
  }

  openActionSheet() {
    this.dialogRef = this.dialog.open(ActionSheetComponent, Constants.MD_DIALOG_CONFIG)
    this.dialogRef.componentInstance.groupByFilterName = "MONTH";
    this.dialogRef.afterClosed().subscribe(result => {
      if (result != undefined && result != "") {
        this.filteredBy = result.filteredBy;
        this.selectedFilterOptions = result.data;
        this.filterArray = [];
        this.getApiCallAccToChoosenFilter(this.filteredBy);
      }
    });

  }

  getApiCallAccToChoosenFilter(filteredBy) {
    switch (filteredBy) {
      case "INVOICE" :
        this.hideFilterButton = false;
        this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRange() : this.getInvoiceDataByMonth();
        break;
      case "CUSTOMER" :
        this.hideFilterButton = false;
        this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeGroupByCustomer() : this.getInvoiceDataGroupByCustomer();
        break;
      case "MONTH":
        this.hideFilterButton = true;
        this.getInvoiceDataGroupByMonth();
        break;
      default :
        break;
    }

  }

  getInvoiceDataGroupByCustomer() {
    this.monthToDateService.getInvoiceDataGroupByCustomer()
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRange() {
    this.invoiceService.getInvoiceDataBetweenDateRange(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate))
      .subscribe((data) => {
        if (data.length > 0) {
          this.isDateRangeSelected = true;
          this.customerData = data;
          this.calculateRevenuePerInvoiceType(this.customerData);
        }
        else {
          this.fromDate = null;
          this.toDate = null;
          this.dialogRef = this.dialog.open(DialogBoxComponent)
        }


      })
  }

  getInvoiceDataBetweenDateRangeGroupByCustomer() {
    this.invoiceService.getInvoiceDataBetweenDateRangeGroupByCustomer(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate))
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  openFilterbySheet() {
    let MD_DIALOG_CONFIG = new MdDialogConfig();
    MD_DIALOG_CONFIG.width = "60%"
    MD_DIALOG_CONFIG.position = {
      bottom: '0px'
    }
    this.dialogRef = this.dialog.open(FilterBySheetComponent, MD_DIALOG_CONFIG)
    this.dialogRef.componentInstance.selectedFilterOptions = this.selectedFilterOptions;
    this.dialogRef.componentInstance.filterArray = this.filterArray;
    this.dialogRef.componentInstance.isSelectAllOptionChecked = this.filterArray.length === this.selectedFilterOptions.length ? true : false;
    this.dialogRef.afterClosed().subscribe(result => {
      if (result != undefined && result.filterArray != undefined) {
        this.filterArray = result.filterArray;
        let data = this.filterArray.toString();
        if (this.filterArray.length > 0) {
          if (this.filteredBy == "INVOICE") {
            this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeFilterByInvoice(data) : this.getInvoiceDataByInvoice(data);
          }
          if (this.filteredBy == "CUSTOMER") {
            this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(data) : this.getInvoiceDataGroupByCustomerFilterByCustomer(data);
          }
        }
        else
          this.getApiCallAccToChoosenFilter(this.filteredBy);
      }
    });
  }

  getInvoiceDataByInvoice(data) {
    this.monthToDateService.getInvoiceDataByInvoice(data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRangeFilterByInvoice(data) {
    this.invoiceService.getInvoiceDataBetweenDateRangeFilterByInvoice(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate), data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(data) {
    this.invoiceService.getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate), data)
      .subscribe((data) => {
        this.customerData = data;
      });
  }

  getInvoiceDataGroupByCustomerFilterByCustomer(data) {
    this.monthToDateService.getInvoiceDataGroupByCustomerFilterByCustomer(data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataGroupByMonth() {
    this.monthToDateService.getInvoiceDataGroupByMonth()
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  swipeLeft() {

  }

  swipeRight() {
    this.router.navigate(['/quartertodate']);
  }

  calculateRevenuePerInvoiceType(array) {
    this.revenueData = [];
    this.total_revenue = 0;
    for (let i = 0; i < Constants.INVOICE_TYPES.length; i++) {
      let total = 0.0;
      array.filter(function (d) {
        if (d.invoiceType == Constants.INVOICE_TYPES[i].value) {
          total = total + parseFloat(d.invoiceAmt);
        }
      });

      this.revenueData.push(total);
      this.total_revenue = this.total_revenue + total;
      this.pieData[i].count = total;
    }
    this.pieChartComponent.createPieChart();
  }

}




