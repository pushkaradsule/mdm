import {Component, OnDestroy} from '@angular/core'
import { AppService } from '../../../app.service';
import {ActivatedRoute, Params, Router} from '@angular/router'

@Component({
    selector: 'reset-password',
    templateUrl: './resetpassword.component.html',
    styleUrls: [
        './resetpassword.component.scss'
    ]
})

export class ResetPasswordComponent implements OnDestroy{

    emailId: string;

    constructor(private appService: AppService,
    private _route : ActivatedRoute,
    private router: Router) {
        appService.getState().pageFullscreen = true;
        let route = this._route.params.subscribe(
            (params: Params) => {
                this.emailId = params["id"];
            }
        )
    }

    ngOnDestroy() {
        this.appService.getState().pageFullscreen = false;
    }

    goToLogin(){
        this.router.navigate(['/login']);  
    }

}