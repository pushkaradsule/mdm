import {Component} from '@angular/core'
import { MdDialogRef } from '@angular/material';
import * as Constants from '../../shared/constants';
import {trigger, state, style, animate, transition} from '@angular/animations';

@Component({
  selector: 'action-sheet',
  templateUrl: './actionsheet.component.html',
  styles: ['./actionsheet.component.scss'],
  animations : [

  ]
})

export class ActionSheetComponent {

  statusTypes = Constants.STATUS_TYPES
  customerTypes = Constants.CUSTOMER_TYPES;
  groupByFilterName: string;

  constructor(private dialogRef: MdDialogRef<ActionSheetComponent>) {

  }



}
