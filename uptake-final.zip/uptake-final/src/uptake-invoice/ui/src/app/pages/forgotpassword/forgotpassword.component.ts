import {Component, OnDestroy} from '@angular/core'
import { AppService } from '../../app.service';
import {Router} from '@angular/router'
import {FormBuilder, Validators, FormGroup} from "@angular/forms";
import * as uptakeMessages from '../../shared/uptakeMessages'


@Component({
    selector: 'forgot-password',
    templateUrl: './forgotpassword.component.html',
    styleUrls: [
        './forgotpassword.component.scss'
    ]
})

export class ForgotPasswordComponent implements OnDestroy {

    emailId: string;
    forgotPasswordForm: FormGroup;
    isSubmitted = false;
    requiredFieldMessage: string;

    constructor(private appService: AppService,
        private router: Router,
        private formBuilder: FormBuilder) {
        appService.getState().pageFullscreen = true;
    }

    ngOnInit() {
        this.requiredFieldMessage = uptakeMessages.REQUIRED_FIELD_MESSAGE;
        this.validationInit();
    }

    validationInit() {
        this.forgotPasswordForm = this.formBuilder.group({
            "email": ["", Validators.required]
        })
    }

    ngOnDestroy() {
        this.appService.getState().pageFullscreen = false;
    }

    goToResetPassword(value) {
        this.isSubmitted = true;
        if (value.valid) {
            console.log(this.emailId)
            this.router.navigate(['/resetpassword/', this.emailId]);
        }
    }
}
