import {Component} from '@angular/core';
import {MdDialog, MdDialogRef} from '@angular/material';


@Component({
  selector: 'dialog-result-example',
  templateUrl: 'dialogbox.component.html',
  styles: ['./dialogbox.component.scss']
})

export class DialogBoxComponent {

  constructor(public dialog: MdDialog) {
  }
}
