import { Component } from '@angular/core';
import { MdDialogRef } from '@angular/material';

@Component({
  selector: 'date-picker',
  templateUrl: './datepicker.component.html',
  styleUrls: [
    './datepicker.component.scss'
  ]
})

export class DatePickerComponent{

 fromDate: Date;
 toDate: Date;

 constructor(private dialogRef: MdDialogRef<DatePickerComponent>){

 }

 search(){

   if(this.fromDate < this.toDate){
    this.dialogRef.close({fromDate: this.fromDate, toDate: this.toDate})
   }

 }

}
