export interface IUserProfile {
  userName: string;
  password?: any;
}

