import {Component, ElementRef, ViewChild, AfterViewInit, Input, ViewEncapsulation} from "@angular/core";
import * as D3 from "d3";
import * as Constants from '../../shared/constants'

@Component({
  selector: "pie-chart",
  templateUrl: "pie-chart.component.html",
  styleUrls: ["pie-chart.component.scss"],
  encapsulation: ViewEncapsulation.None
})

export class PieChartComponent implements AfterViewInit {
  @ViewChild("containerPieChart") element: ElementRef;

  private host: any;
  private svg: any;
  private width: number;
  private height: number;
  private radius: number;
  private htmlElement: HTMLElement;
  private pieData: any[];
  private pie: any;

  @Input()
  revenueData: any;

  constructor() {
  }

  ngAfterViewInit() {
  }

  createPieChart() {
    this.pieData = this.revenueData;
    this.setup();
  }

  private setup(): void {
    this.htmlElement = this.element.nativeElement;
    this.host = D3.select(this.htmlElement);
    this.width = 250;
    this.height = 250;
    this.radius = Math.min(this.width, this.height) / 2;

    this.buildPie();
    this.buildSVG();
  }

  private buildSVG(): void {
    var outerRadiusArc = this.width / 2;
    var innerRadiusArc = this.radius - 50;

    this.host.html("");
    this.svg = this.host
      .classed("svg-container", true)
      .append("svg")
      .attr("preserveAspectRatio", "xMinYMin meet")
      .attr("viewBox", `0 0 ${this.width} ${this.height}`)
      .classed("svg-content-responsive", true)
      .append("g")
      .attr("transform", `translate(${this.width / 2},${this.height / 2})`);


    let color = D3.scaleOrdinal()
      .range(["#0653ab", "#1f7ddb", "#68acfa", "#ccc"]);


    var mainChart = this.createChart(this.svg, outerRadiusArc, innerRadiusArc, function (d, i) {
      return color(d.data.name);
    }, 'path1');

  }


  createChart(svg, outerRadius, innerRadius, fillFunction, className) {
    var arc = D3.arc()
      .innerRadius(outerRadius)
      .outerRadius(innerRadius);
    var path = svg.selectAll('.' + className)
      .data(this.pie(this.pieData))
      .enter()
      .append('path')
      .attr("class", className)
      .attr("d", arc)
      .attr("fill", fillFunction);

    path.transition()
      .duration(1000)
      .attrTween('d', function (d) {
        var interpolate = D3.interpolate({startAngle: 0, endAngle: 0}, d);
        return function (t) {
          return arc(interpolate(t));
        };
      });

    var chart = {path: path, arc: arc};
    return chart;
  };


  private buildPie(): void {
    var total = 0;
    this.pieData.forEach(function (d) {
      total += d.count;
    });
    this.pie = D3.pie()
      .value(function (d) {
        return d.count
      })
      .sort(null);
  }

}
