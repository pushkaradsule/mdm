import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import {AppService} from '../../app.service';
import {InvoiceService} from '../../services/invoices.service'
import {Invoice} from '../models/invoice.model'
import {BaseClass} from '../../shared/base.class';
import * as moment from "moment";
import Base = moment.unitOfTime.Base;

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styles: ['./dashboard.component.scss']
})

export class DashboardComponent extends BaseClass{

  dashboardData : Invoice[]= [];

   constructor(private appService: AppService,
   private router: Router,
               private invoiceService : InvoiceService) {
     super();
      this.appService.getState().pageFooter = true;
  }

  ngOnInit(){
     this.getDashboardData()
  }

  getDashboardData(){
     this.invoiceService.getDashboardData()
       .subscribe((data) => {
         this.dashboardData = data;
       })
  }

  goToMonthToDate(){
    this.router.navigate(['/monthtodate']);
  }

  goToQuarterToDate(){
    this.router.navigate(['/quartertodate']);
  }

  goToYearToDate(){
    this.router.navigate(['/yeartodate']);
  }

  swipeRight() {
  }

  swipeLeft() {
  }

}
