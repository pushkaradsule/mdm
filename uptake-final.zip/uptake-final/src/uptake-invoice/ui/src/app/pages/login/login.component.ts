import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from '../../app.service';
import { Router } from '@angular/router'
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import * as uptakeMessages from '../../shared/uptakeMessages'
import { LoginService } from "../../services/login.service";
import { StorageService } from "../../shared/storage.service";

@Component({
  selector: 'lk-pages-signin',
  templateUrl: './login.component.html',
  styleUrls: [
    './login.component.scss'
  ]
})
export class LoginComponent implements OnInit, OnDestroy {

  loginForm: FormGroup;
  isSubmitted = false;
  requiredFieldMessage: string;

  constructor(private appService: AppService,
    private router: Router,
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private storageService: StorageService) {

    appService.getState().pageFullscreen = true;
    this.appService.getState().pageFooter = false;

  }

  ngOnInit() {
    this.requiredFieldMessage = uptakeMessages.REQUIRED_FIELD_MESSAGE;
    this.storageService.removeAllkeys();
    this.validationInit();
  }

  validationInit() {
    this.loginForm = this.formBuilder.group({
      "userName": ["", Validators.required],
      "password": ["", Validators.required]
    })
  }

  ngOnDestroy() {
    this.appService.getState().pageFullscreen = false;
  }

  goToForgotPassword() {
    this.router.navigate(['/forgotpassword']);
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  login(form) {
    this.isSubmitted = true;
    if (form.valid) {
       this.loginService.login(form.value).subscribe((data) => {
         this.storageService.setUserAuthToken(data.results.token);
        this.router.navigate(['/dashboard']);
       })

    }
  }

}
