import {Component, ViewChild} from '@angular/core'
import {Router} from '@angular/router';
import {MdDialog, MdDialogConfig} from '@angular/material';
import {FilterBySheetComponent} from '../../filterbysheet/filterbysheet.component';
import {ActionSheetComponent} from '../../actionsheet/actionsheet.component';
import {Invoice} from '../../models/invoice.model';
import {AppService} from '../../../app.service';
import * as Constants from '../../../shared/constants';
import {YearToDateService} from '../../../services/yeartodate.service';

import {InvoiceService} from '../../../services/invoices.service';
import {PieChartComponent} from "../../pie-chart/pie-chart.component";
import {BaseClass} from '../../../shared/base.class';
import {DialogBoxComponent} from "../dialogbox/dialogbox.component";

@Component({
  selector: 'yeartodate',
  templateUrl: './yeartodate.component.html',
  styles: ['./yeartodate.component.scss']
})

export class YearToDateComponent extends BaseClass {
  customerData: Invoice[] = [];
  revenueData: number[] = [];
  pieData = Constants.PIE_DATA;
  dialogRef: any;
  selectedFilterOptions = [];
  filterArray = [];
  filteredBy: string;
  isDateRangeSelected: boolean = false;
  fromDate: Date;
  toDate: Date;
  @ViewChild(PieChartComponent) pieChartComponent: PieChartComponent
  invoice_names = Constants.INVOICE_NAMES;
  total_revenue: number = 0;
  hideFilterButton: boolean = false;

  constructor(private router: Router,
              public dialog: MdDialog,
              private appService: AppService,
              private yearToDateService: YearToDateService,
              private invoiceService: InvoiceService) {
    super();
    this.appService.getState().pageFooter = true;

  }

  ngOnInit() {
    this.filteredBy = "INVOICE";
    this.selectedFilterOptions = Constants.STATUS_TYPES;
    this.getInvoiceDataByYear();
  }

  getInvoiceDataByYear() {
    this.yearToDateService.getInvoiceDataByYear()
      .subscribe((data) => {
        this.customerData = data;
        this.calculateRevenuePerInvoiceType(this.customerData)
      })
  }

  searchInvoiceBetweenGivenRange() {
    if (this.fromDate < this.toDate) {
      this.filterArray = [];
      this.getInvoiceDataBetweenDateRange();
    }
  }

  openActionSheet() {
    this.dialogRef = this.dialog.open(ActionSheetComponent, Constants.MD_DIALOG_CONFIG);
    this.dialogRef.componentInstance.groupByFilterName = "YEAR";
    this.dialogRef.afterClosed().subscribe(result => {
      if (result != undefined && result != '') {
        this.filteredBy = result.filteredBy;
        this.selectedFilterOptions = result.data;
        this.filterArray = [];
        this.getApiCallAccToChoosenFilter(this.filteredBy);
      }
    });
  }

  getInvoiceDataGroupByCustomer() {
    this.yearToDateService.getInvoiceDataGroupByCustomer()
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRangeGroupByCustomer() {
    this.invoiceService.getInvoiceDataBetweenDateRangeGroupByCustomer(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate))
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getApiCallAccToChoosenFilter(filteredBy) {
    switch (filteredBy) {
      case "INVOICE" :
        this.hideFilterButton = false;
        this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRange() : this.getInvoiceDataByYear();
        break;
      case "CUSTOMER" :
        this.hideFilterButton = false;
        this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeGroupByCustomer() : this.getInvoiceDataGroupByCustomer();
        break;
      case "YEAR":
        this.hideFilterButton = true;
        this.getInvoiceDataGroupByYear();
        break;
      default :
        break;
    }
  }

  openFilterbySheet() {
    let MD_DIALOG_CONFIG = new MdDialogConfig();
    MD_DIALOG_CONFIG.width = "60%"
    MD_DIALOG_CONFIG.position = {
      bottom: '0px'
    }
    this.dialogRef = this.dialog.open(FilterBySheetComponent, MD_DIALOG_CONFIG)
    this.dialogRef.componentInstance.selectedFilterOptions = this.selectedFilterOptions;
    this.dialogRef.componentInstance.filterArray = this.filterArray;
    this.dialogRef.componentInstance.isSelectAllOptionChecked = this.filterArray.length === this.selectedFilterOptions.length ? true : false;
    this.dialogRef.afterClosed().subscribe(result => {
      if (result != undefined && result.filterArray != undefined) {
        this.filterArray = result.filterArray;
        let data = this.filterArray.toString();
        if (this.filterArray.length > 0) {
          if (this.filteredBy == "INVOICE") {
            this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeFilterByInvoice(data) : this.getInvoiceDataByStatus(data)
          }
          if (this.filteredBy == "CUSTOMER") {
            this.isDateRangeSelected ? this.getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(data) : this.getInvoiceDataGroupByCustomerFilterByType(data);
          }
        }
        else
          this.getApiCallAccToChoosenFilter(this.filteredBy)
      }

    });

  }

  getInvoiceDataBetweenDateRangeFilterByInvoice(data) {
    this.invoiceService.getInvoiceDataBetweenDateRangeFilterByInvoice(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate), data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(data) {
    this.invoiceService.getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate), data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataByStatus(data) {
    this.yearToDateService.getInvoiceDataByStatus(data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataGroupByCustomerFilterByType(data) {
    this.yearToDateService.getInvoiceDataGroupByCustomerFilterByType(data)
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  getInvoiceDataBetweenDateRange() {
    this.invoiceService.getInvoiceDataBetweenDateRange(Constants.getDateFormat(this.fromDate), Constants.getDateFormat(this.toDate))
      .subscribe((data) => {
        if (data.length > 0) {
          this.isDateRangeSelected = true;
          this.customerData = data;
          this.calculateRevenuePerInvoiceType(this.customerData);
        }
        else {
          this.fromDate = null;
          this.toDate = null;
          this.dialogRef = this.dialog.open(DialogBoxComponent)
        }
      })
  }

  getInvoiceDataGroupByYear() {
    this.yearToDateService.getInvoiceDataGroupByYear()
      .subscribe((data) => {
        this.customerData = data;
      })
  }

  swipeLeft() {
    this.router.navigate(['/quartertodate']);
  }

  swipeRight() {

  }

  calculateRevenuePerInvoiceType(array) {
    this.revenueData = [];
    this.total_revenue = 0;
    for (let i = 0; i < Constants.INVOICE_TYPES.length; i++) {
      let total = 0;
      array.filter(function (d) {
        if (d.invoiceType == Constants.INVOICE_TYPES[i].value) {
          total = total + parseFloat(d.invoiceAmt);
        }
      });
      this.revenueData.push(total);
      this.total_revenue = this.total_revenue + total;
      this.pieData[i].count = total;
    }
    this.pieChartComponent.createPieChart();
  }

}
