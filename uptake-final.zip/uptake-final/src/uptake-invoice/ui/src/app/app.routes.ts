import {Routes} from '@angular/router';
import {DashboardComponent} from './pages/dashboard/dashboard.component';
import {LoginComponent} from './pages/login/login.component';
import {MonthToDateComponent} from './pages/revenue/monthtodate/monthtodate.component';
import {QuarterToDateComponent} from './pages/revenue/quartertodate/quartertodate.component';
import {DatePickerComponent} from './pages/datepicker/datepicker.component';
import {AuthGuardService} from "./shared/auth-guard.service";

import {ForgotPasswordComponent} from './pages/forgotpassword/forgotpassword.component';
import {ResetPasswordComponent} from './pages/forgotpassword/resetpassword/resetpassword.component';
import {YearToDateComponent} from './pages/revenue/yeartodate/yeartodate.component';

export const ROUTES: Routes = [

  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuardService]
  },

  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'forgotpassword',
    component: ForgotPasswordComponent
  },
  {
    path: 'resetpassword/:id',
    component: ResetPasswordComponent
  },
  {
    path: 'monthtodate',
    component: MonthToDateComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'quartertodate',
    component: QuarterToDateComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'yeartodate',
    component: YearToDateComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'datepicker',
    component: DatePickerComponent
  }


];
