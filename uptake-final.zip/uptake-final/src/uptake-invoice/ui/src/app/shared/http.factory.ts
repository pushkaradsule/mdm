import {XHRBackend, Http, RequestOptions} from '@angular/http';

import {HttpInterceptor} from './http.interceptor';
import {StorageService} from "./storage.service";
import {Broadcaster} from "./Broadcaster";

export function httpFactory(xhrBackend: XHRBackend,
                            requestOptions: RequestOptions,
                            storageService: StorageService,
                            broadcaster: Broadcaster, ): Http {
  return new HttpInterceptor(xhrBackend, requestOptions, storageService, broadcaster);
}
