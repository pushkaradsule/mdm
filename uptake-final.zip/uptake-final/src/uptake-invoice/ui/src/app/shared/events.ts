export const LOGIN_FAILED = "Login Failed";
export const SPINNER_START = "Loader Start";
export const SPINNER_STOP = "Loader Stop";
