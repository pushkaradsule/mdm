import {Injectable} from '@angular/core';
import {
  Http,
  Request,
  RequestOptions,
  RequestOptionsArgs,
  Response,
  ConnectionBackend,
  Headers
} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/finally';
import {StorageService} from "./storage.service";
import {Broadcaster} from "./Broadcaster";

import * as events from './events';
import * as _ from 'lodash'
import * as messages from './uptakeMessages';

@Injectable()
export class HttpInterceptor extends Http {

  constructor(connectbackend: ConnectionBackend,
              defaultOptions: RequestOptions,
              private storageService: StorageService,
              private broadcaster: Broadcaster) {
    super(connectbackend, defaultOptions);
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.request(url, options));
  }

  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    this.broadcaster.broadcast(events.SPINNER_START);
    return this.intercept(super.get(url, this.createAuthorizationHeader(options))
      .do(data => {
        this.broadcaster.broadcast(events.SPINNER_STOP);
      })
    );
  }

  post(url: string, body: string, options?: RequestOptionsArgs): Observable<Response> {
    this.broadcaster.broadcast(events.SPINNER_START);
    return this.intercept(super.post(url, body, this.getRequestOptionArgs(url, options))
      .do(data => {
        this.broadcaster.broadcast(events.SPINNER_STOP);
      })
    );
  }

  put(url: string, body: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.put(url, body, this.getRequestOptionArgs(url, options)));
  }

  delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.delete(url, options));
  }

  createAuthorizationHeader(options?: RequestOptionsArgs): RequestOptionsArgs {
    let authHeader;
    if (options == null) {
      options = new RequestOptions();
    }
    if (options.headers == null) {
      options.headers = new Headers();
    }

    authHeader = this.storageService.getUserAuthToken();
    if (authHeader) {
      options.headers.append('Authorization', authHeader);
    }
    return options;
  }


  getRequestOptionArgs(url: string, options?: RequestOptionsArgs): RequestOptionsArgs {
    if (options == null) {
      options = new RequestOptions();
    }
    if (options.headers == null) {
      options.headers = new Headers();
      options.headers.append('Content-Type', 'application/json');
    }

    if (!_.endsWith(url, 'api/login')) {
      options = this.createAuthorizationHeader(options);
    }
    return options;
  }

  NoConnectity(): Observable<Response> {
    return Observable.throw({
      _body: '{"error_description" : "no internet connectivity", "error":"no internet connectivity"}',
      status: 503,
      statusText: 'no internet connectivity'
    });
  }

  intercept(observable: Observable<Response>): Observable<Response> {
    return observable.catch((err, source) => {
      if (err.status === 401) {
        this.broadcaster.broadcast(events.LOGIN_FAILED, messages.LOGIN_FAILURE);
        return Observable.empty();
      } else if (err.status === 500) {
        return Observable.empty();
      }
      else if (err.status === 504) {
        return Observable.empty();

      }
      else {
        return Observable.throw(err);
      }
    });

  }
}
