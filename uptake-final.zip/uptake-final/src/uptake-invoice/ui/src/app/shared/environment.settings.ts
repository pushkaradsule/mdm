export var API_ENDPOINT = 'http://uptake.bitwiseglobal.com';
export var TIMEOUT_VALUE = 3000;

export var DATE_FORMAT = 'dd/MM/yyyy HH:mm';

export var CURRENCY_CODE = 'USD';
export var SYMBOL_DISPLAY = true;
export var DIGIT_INFO = '4.0-2';
