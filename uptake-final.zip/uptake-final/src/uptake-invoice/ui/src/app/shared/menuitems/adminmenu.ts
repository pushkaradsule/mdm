/**
 * Menu data mock
 */
export class AdminMenu {
  static root = [
    {
      name: 'home',
      title: 'Home',
      faIcon: 'prefix icon-home',
      link: '/dashboard'
    },
    {
      name: 'profile',
      title: 'Profile',
      faIcon: 'prefix icon-prfole',
      link: '/dashboard'
    },
    {
      name: 'settings',
      title: 'Settings',
      faIcon: 'prefix icon-settings',
      link: '/dashboard'
    },
    {
      name: 'contact',
      title: 'Contact',
      faIcon: 'prefix icon-contact',
      link: '/dashboard'
    },
    {
      name: 'logout',
      title: 'Log out',
      faIcon: 'prefix icon-logout',
      link: '/login'
    }
  ];
}
