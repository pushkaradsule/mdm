import {OnInit} from "@angular/core";
import {CURRENCY_CODE, SYMBOL_DISPLAY, DIGIT_INFO} from './environment.settings'

export abstract class BaseClass implements OnInit{

  CURRENCY_CODE = CURRENCY_CODE;
  SYMBOL_DISPLAY = SYMBOL_DISPLAY;
  DIGIT_INFO = DIGIT_INFO;

  constructor(){

  }

  ngOnInit() {
    this.swipeLeft();
    this.swipeRight();
  }

  abstract swipeRight();
  abstract swipeLeft();

}
