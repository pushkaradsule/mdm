import {Injectable} from "@angular/core";

@Injectable()
export class StorageService {

  private setObjectValue(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  private getObjectValue(key) {
    let item = localStorage.getItem(key);
    if (item)
      return JSON.parse(item);
    return null;
  }

  getUserAuthToken() {
    return this.getObjectValue("AUTH_TOKEN");
  }

  setUserAuthToken(token) {
    this.setObjectValue("AUTH_TOKEN", token);
  }

  removeAllkeys() {
    localStorage.clear();
  }

  getFullName() {
    return this.getObjectValue("FULL_NAME");
  }

  setFullName(value) {
    this.setObjectValue("FULL_NAME", value);
  }
}
