import {Injectable} from "@angular/core";
import { MdSnackBar } from '@angular/material';

@Injectable()
export class NotificationService {

  private snackBarRef: any;
  time = 3000;

  constructor(public snackBar: MdSnackBar) {
  }

  closeNotify() {
    if (this.snackBarRef)
      this.snackBarRef.dismiss();
  }

  openNotify(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: this.time,
    });
  }

}
