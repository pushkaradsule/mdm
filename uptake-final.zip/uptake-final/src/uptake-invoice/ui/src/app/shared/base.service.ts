import {Observable} from 'rxjs/Observable';

export class BaseService {

  constructor() {

  }

  handleError(error: any) {

    var errorMessage = JSON.parse(error._body).error_description;

    let errMsg = (errorMessage) ? errorMessage :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';

    return Observable.throw(errMsg);
  }

}
