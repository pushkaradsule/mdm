import {MdDialogConfig} from '@angular/material';
import * as moment from 'moment/moment'

export const STATUS_TYPES = [
  {name: "BILLED", value: "BILLED"},
  {name: "PENDING", value: "PENDING"}
];


export const CUSTOMER_TYPES = [
  {name: "REVENUE", value: "RVN"},
  {name: "INTERNAL", value: "INT"},
  {name: "PROSPECT", value: "PCT"},
  {name: "OTHER", value: "OTH"}
];

export const INVOICE_TYPES = [
  {name: "SALES", value: "EQT"},
  {name: "RENTAL", value: "RNT"},
  {name: "LABOR", value: "LBR"},
  {name: "PARTS", value: "PTS"}
];

export const PIE_DATA = [
  {name: "SALES", count: 0},
  {name: "RENTAL", count: 0},
  {name: "LABOR", count: 0},
  {name: "PARTS", count: 0}
];

export enum INVOICE_NAMES {
  'EQT' = 'Sales',
  'LBR' = 'Labor',
  'RNT' = 'Rental',
  'PTS' = 'Parts'
}


export const DATE_FORMAT = "YYYY/MM/D";

export const MD_DIALOG_CONFIG = new MdDialogConfig();
MD_DIALOG_CONFIG.width = "80%"
MD_DIALOG_CONFIG.position = {
  bottom: '0px'
};

export function getDateFormat(date: Date) {
  return moment(date).format(DATE_FORMAT)
}


