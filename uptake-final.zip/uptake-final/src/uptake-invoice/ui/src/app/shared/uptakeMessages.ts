export const REQUIRED_FIELD_MESSAGE = "Required Field.";
export const LOGIN_FAILURE = "Authorization Failed. Please Login again";
