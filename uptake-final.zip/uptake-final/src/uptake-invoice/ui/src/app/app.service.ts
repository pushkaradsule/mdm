import {Injectable} from '@angular/core';

export type InternalStateType = {
  [key: string]: any,
  appName: string,
  defaultLang: string,
  topnavTitle: string,
  messagePanelOpen: boolean,
  sidenavOpen: boolean,
  sidenavMode: string,
  sidenavCollapse: boolean,
  pageFooter: boolean,
  initial: boolean,
};

@Injectable()
export class AppService {

  private state: InternalStateType = {
    appName: 'uptake-invoice-client',
    defaultLang: 'en',
    topnavTitle: 'Uptake',
    messagePanelOpen: false,
    sidenavOpen: false,
    sidenavMode: 'over',
    sidenavCollapse: true,
    pageFooter: false,
    initial: false,
  };

  public cloneState(): InternalStateType {
    return JSON.parse(JSON.stringify(this.state));
  }

  public reloadState(state: InternalStateType) {
    this.state = state;
  }

  public getState(prop?: any): InternalStateType {
    const state = this.state;
    return state.hasOwnProperty(prop) ? state[prop] : state;
  }

  public setState(prop: string, value: any) {
    return this.state[prop] = value;
  }
}
