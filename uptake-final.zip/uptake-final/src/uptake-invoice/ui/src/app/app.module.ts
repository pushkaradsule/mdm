import { ROUTES } from './app.routes';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms'
import { NgModule } from '@angular/core';
import { HttpModule, Http, RequestOptions, XHRBackend } from '@angular/http';
import {httpFactory} from "./shared/http.factory";
import { AppComponent } from './app.component';
import { AppService } from './app.service';
import { MaterialModule, MdNativeDateModule, MdDatepicker } from '@angular/material';
import { Md2Module } from 'md2/module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ContainerComponent } from './pages/container/container.component';
import { LoginComponent } from './pages/login/login.component';
import { MonthToDateComponent } from './pages/revenue/monthtodate/monthtodate.component';
import { QuarterToDateComponent } from './pages/revenue/quartertodate/quartertodate.component';
import { YearToDateComponent } from './pages/revenue/yeartodate/yeartodate.component';
import { PieChartComponent } from './pages/pie-chart/pie-chart.component';
import { DatePickerComponent } from './pages/datepicker/datepicker.component';
import { FilterBySheetComponent } from './pages/filterbysheet/filterbysheet.component'
import { ActionSheetComponent } from './pages/actionsheet/actionsheet.component'
import { LoginService } from './services/login.service'
import {MonthToDateService} from './services/monthtodate.service'
import {YearToDateService} from './services/yeartodate.service'
import {InvoiceService} from './services/invoices.service'
import {QuarterToDateService} from './services/quartertodate.service'
import { StorageService } from "./shared/storage.service";
import {AuthGuardService} from "./shared/auth-guard.service";

import { ForgotPasswordComponent } from './pages/forgotpassword/forgotpassword.component';
import { ResetPasswordComponent } from './pages/forgotpassword/resetpassword/resetpassword.component';

import { HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import {NotificationService} from "./shared/notifications.service";

import {LoaderComponent} from "./pages/loader/loader.component";
import {LoaderService} from "./services/loader.service";
import {Broadcaster} from "./shared/Broadcaster";
import {DialogBoxComponent} from './pages/revenue/dialogbox/dialogbox.component'

export class MyHammerConfig extends HammerGestureConfig {
  overrides = <any>{
    'swipe': { velocity: 0.4, threshold: 20 }
  }
}


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    MonthToDateComponent,
    QuarterToDateComponent,
    PieChartComponent,
    DatePickerComponent,
    ContainerComponent,
    ActionSheetComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    FilterBySheetComponent,
    YearToDateComponent,
    LoaderComponent,
    DialogBoxComponent
  ],
  imports: [

    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(ROUTES),
    MaterialModule,
    MdNativeDateModule,
    FlexLayoutModule,
    Md2Module
  ],
  entryComponents: [ActionSheetComponent, FilterBySheetComponent, DialogBoxComponent],
  providers: [
    AppService,
    LoginService,
    MonthToDateService,
    StorageService,
    YearToDateService,
    QuarterToDateService,
    InvoiceService,
    NotificationService,
    MdDatepicker,
    AuthGuardService,
    LoaderService,
    Broadcaster,
    {
      provide: HAMMER_GESTURE_CONFIG,
      useClass: MyHammerConfig
    },
    {
      provide: Http,
      useFactory: httpFactory,
      deps: [XHRBackend, RequestOptions, StorageService, Broadcaster]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
