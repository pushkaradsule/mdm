import {Injectable} from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Http, RequestOptions, Headers} from "@angular/http";
import {API_ENDPOINT} from "../shared/environment.settings";
import {BaseService} from "../shared/base.service";

@Injectable()
export class LoginService extends BaseService {

  constructor(private http: Http) {
    super();
  }

  login(data: any) {
    let options: RequestOptions;
    options = new RequestOptions();
    options.headers = new Headers();
    options.headers.append('Content-Type', 'application/json');

    return this.http.post(API_ENDPOINT + "/api/login", data, options)
      .map(response => response.json())
      .catch(this.handleError);
  }
}
