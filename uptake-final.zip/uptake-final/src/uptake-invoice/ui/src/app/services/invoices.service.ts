import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { Http } from "@angular/http";
import { API_ENDPOINT } from "../shared/environment.settings";
import { BaseService } from "../shared/base.service";
import { Observable } from "rxjs/Observable";
import { Invoice } from "../pages/models/invoice.model";


@Injectable()
export class InvoiceService extends BaseService {

  constructor(private http: Http) {
    super();
  }

  getInvoiceDataBetweenDateRange(startDate, endDate): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/invoices?startDate=' + startDate + '&endDate=' + endDate)
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataBetweenDateRangeGroupByCustomer(startDate, endDate): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/invoices?startDate=' + startDate + '&endDate=' + endDate + '&group-by=customerNumber')
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataBetweenDateRangeFilterByInvoice(startDate, endDate, data): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/invoices?startDate=' + startDate + '&endDate=' + endDate + '&invoicestatus='+data)
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataBetweenDateRangeGroupByCustomerFilterByCustomer(startDate, endDate, data): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/invoices?startDate=' + startDate + '&endDate=' + endDate + '&group-by=customerNumber&customertype='+data)
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getDashboardData() : Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/dashboard')
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }
}
