import {Injectable} from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {Http} from "@angular/http";
import {API_ENDPOINT} from "../shared/environment.settings";
import {BaseService} from "../shared/base.service";
import {Observable} from "rxjs/Observable";
import {Invoice} from "../pages/models/invoice.model";


@Injectable()
export class QuarterToDateService extends BaseService {

  constructor(private http: Http) {
    super();
  }

  getInvoiceDataByQuarter(): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/quartertodate')
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataByStatus(data): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/quartertodate?invoicestatus=' + data)
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataGroupByCustomer() {
    return this.http.get(API_ENDPOINT + '/api/quartertodate?group-by=customerNumber')
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataGroupByCustomerFilterByType(data) {
    return this.http.get(API_ENDPOINT + '/api/quartertodate?group-by=customerNumber&customertype=' + data)
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }

  getInvoiceDataGroupByQuarter(): Observable<Invoice[]> {
    return this.http.get(API_ENDPOINT + '/api/invoices?group-by=quarter')
      .map(response => <Invoice[]>response.json())
      .catch(this.handleError);
  }
}
