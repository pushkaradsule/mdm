import {Component, ViewEncapsulation, OnInit} from '@angular/core';
import {AppService} from './app.service';
import {AdminMenu} from './shared/menuitems/adminmenu';
import {NotificationService} from "./shared/notifications.service";
import {LoaderService} from "./services/loader.service";
import {StorageService} from "./shared/storage.service";
import {Broadcaster} from "./shared/Broadcaster";
import {Router} from "@angular/router";



import * as events from './shared/events';

@Component({
  selector: 'pc-app',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './app.component.html',
  styleUrls: [
    './app.component.scss'
  ]
})
export class AppComponent implements OnInit {

  // Mock Menu
  mainMenu = AdminMenu.root;
  activeSubMenuName: string;
  snackBarRef: any;

  constructor(private appService: AppService,
              private router: Router,
              private broadcaster: Broadcaster,
              private storageService: StorageService,
              private notificationService: NotificationService,
              private loaderService: LoaderService) {
    this.registerLoginFailedBroadcast();
    appService.getState().topnavTitle = 'Invoices & Revenues';
  }

  ngOnInit() {
  }

  toggleSidenavCollapse() {
    if (this.appService.getState().sidenavCollapse) {
      this.resizeSidenav();
    }
  }

  toggleSidenav() {
    this.appService.getState().sidenavOpen = !this.appService.getState().sidenavOpen;
    this.resizeSidenav();
  }

  closeSidenav() {
    this.appService.getState().sidenavOpen = false;
    this.resizeSidenav();
  }

  openSidenav() {
    this.appService.getState().sidenavOpen = true;
    this.resizeSidenav();
  }

  resizeSidenav() {
    if (this.appService.getState().sidenavMode === 'side') {
      let resizeEvent = document.createEvent('HTMLEvents');
      resizeEvent.initEvent('resize', true, true);
      document.dispatchEvent(resizeEvent);
    }
  }

  toggleSidenavMenu(menuName: string, isSub: boolean, isParent: boolean) {
    if (isParent) {
      this.activeSubMenuName = this.activeSubMenuName === menuName ? null : menuName;
      return;
    }

    if (isSub) {
      if (this.appService.getState().sidenavMode === 'push' ||
        this.appService.getState().sidenavMode === 'over') {
        this.toggleSidenav();
      }
      return;
    }

    this.activeSubMenuName = null;
    if (this.appService.getState().sidenavMode === 'push' ||
      this.appService.getState().sidenavMode === 'over') {
      this.toggleSidenav();
    }
  }

  registerLoginFailedBroadcast() {
    this.broadcaster.on<string>(events.LOGIN_FAILED)
      .subscribe(message => {
        this.notificationService.openNotify(message, 'Close');
        this.logOut();
      });

    this.broadcaster.on<string>(events.SPINNER_START)
      .subscribe(() => {
        this.loaderService.show();
      });

    this.broadcaster.on<string>(events.SPINNER_STOP)
      .subscribe(() => {
        this.loaderService.hide()
      });

  }

  redirect(redirectUrl: string) {
    this.router.navigate([redirectUrl]);
  }

  logOut() {
    this.storageService.removeAllkeys();
    this.redirect("/login");
  }

}
