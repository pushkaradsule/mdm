import mobiscroll from '../core/core';
export default class Radio {
    constructor(element: any, settings: any);
}