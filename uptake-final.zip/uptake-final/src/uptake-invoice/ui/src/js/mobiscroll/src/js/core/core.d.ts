import mobiscroll from './mobiscroll';
export default mobiscroll;
export const $: any;
export const extend: any;