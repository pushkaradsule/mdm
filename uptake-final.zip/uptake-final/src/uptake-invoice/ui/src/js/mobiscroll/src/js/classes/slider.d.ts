import mobiscroll from '../core/core';
export default class Slider {
    constructor(element: any, settings: any);
}