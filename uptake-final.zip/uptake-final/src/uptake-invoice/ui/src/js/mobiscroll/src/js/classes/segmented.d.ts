import mobiscroll from '../core/core';
export default class SegmentedItem {
    constructor(element: any, settings: any);
}