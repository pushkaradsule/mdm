import mobiscroll from '../core/core';
export default class ListView {
    constructor(element: any, settings: any)
}