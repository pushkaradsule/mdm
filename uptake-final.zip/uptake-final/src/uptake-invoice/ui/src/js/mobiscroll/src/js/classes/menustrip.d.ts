import mobiscroll from '../core/core';
export default class MenuStrip {
    constructor(elem: any, settings: any);
}