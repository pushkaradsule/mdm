import mobiscroll from '../core/core';
export default class Color {
    constructor(element: any, settings: any);
}
