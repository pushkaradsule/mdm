import mobiscroll from '../core/core';
export default class Switch {
    constructor(element: any, settings: any);
}