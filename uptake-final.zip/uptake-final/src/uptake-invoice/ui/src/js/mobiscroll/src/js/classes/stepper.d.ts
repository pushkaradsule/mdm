import mobiscroll from '../core/core';
export default class Stepper {
    constructor(element: any, settings: any);
}