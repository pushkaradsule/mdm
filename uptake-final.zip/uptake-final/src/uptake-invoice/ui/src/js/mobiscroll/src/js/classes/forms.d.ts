import mobiscroll from '../core/core';
export default class Form {
    constructor(element: any, settings: any);
}