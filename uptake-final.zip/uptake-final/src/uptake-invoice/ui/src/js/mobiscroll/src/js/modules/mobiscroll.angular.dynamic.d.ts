import { mobiscroll } from '../frameworks/angular';
declare class MbscModule {
}
export { mobiscroll, MbscModule };
