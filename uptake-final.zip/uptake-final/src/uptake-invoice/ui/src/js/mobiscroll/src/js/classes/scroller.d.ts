import mobiscroll from '../core/core';
export default class Scroller {
    constructor(element: any, settings: any);
}
