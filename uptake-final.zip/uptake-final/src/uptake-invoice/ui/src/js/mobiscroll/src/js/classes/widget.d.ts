import mobiscroll from '../core/core';
export default class Widget {
    constructor(element: any, settings: any);
}
