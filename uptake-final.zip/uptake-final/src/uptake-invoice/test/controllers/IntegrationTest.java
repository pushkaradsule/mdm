package controllers;


import com.fasterxml.jackson.databind.JsonNode;

import com.uptake.invoice.common.GenericResponse;
import com.uptake.invoice.common.UptakeMessages;
import com.uptake.invoice.resources.InvoiceResource;
import com.uptake.invoice.resources.UserResource;
import com.uptake.invoice.security.AuthUtils;
import org.junit.Before;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Result;
import play.test.WithApplication;

import java.util.HashMap;

import java.util.Map;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.*;
import static play.test.Helpers.*;

/**
 * Created by apurvav on 17-07-2017.
 */
public class IntegrationTest extends WithApplication {
    @Override
    protected Application provideApplication() {

        return new GuiceApplicationBuilder().build();
    }

    private String token;

    @Before
    public void GetUserToken() {

        UserResource u = new UserResource("apurva", "1234");
        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(POST)
                .bodyJson(Json.toJson(u))
                .uri("/api/login");

        Result result = route(app, request);
        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        GenericResponse response = Json.fromJson(customDataJsonNode, GenericResponse.class);

        Map tokenJson = (java.util.LinkedHashMap) response.getResults();

        token = tokenJson.get("token").toString();

    }

    @Test
    public void valid_user_should_allowed_to_login() {
        UserResource u = new UserResource("apurva", "1234");
        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(POST)
                .bodyJson(Json.toJson(u))
                .uri("/api/login");

        Result result = route(app, request);
        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        GenericResponse response = Json.fromJson(customDataJsonNode, GenericResponse.class);

        assertTrue(response.isSuccess);

        //check of token
        JsonNode tokenCheckResponse = Json.toJson(response.getResults());

        assertTrue(tokenCheckResponse.hasNonNull("token"));

    }

    @Test
    public void invalid_user_should_not_allowed_to_login() {

        UserResource u = new UserResource("abc@gmai1l.com", "1234");
        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(POST)
                .bodyJson(Json.toJson(u))
                .uri("/api/login");

        Result result = route(app, request);

        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        GenericResponse response = Json.fromJson(customDataJsonNode, GenericResponse.class);

        //condition should be false
        assertTrue(!response.isSuccess);

        //should have invalid login message
        Map<String, String> map = (HashMap<String, String>) response.getErrorMessage().get(0);

        assertEquals(UptakeMessages.ErrorMessages.LOGIN_FAILED.getMessage(),
                map.get(UptakeMessages.ErrorMessages.LOGIN_FAILED.toString()));

    }

    @Test
    public void unauthorised_response_for_invoices() {

        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(GET)
                .uri("/api/invoices");
        Result result = route(app, request);
        assertThat(result.status(), equalTo(UNAUTHORIZED));

    }

    @Test
    public void valid_user_should_get_invoices() {


        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(GET)
                .header(AuthUtils.AUTH_HEADER_KEY, token)
                .uri("/api/invoices");

        Result result = route(app, request);

        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        InvoiceResource[] responseInvoices = Json.fromJson(customDataJsonNode, InvoiceResource[].class);

        assertNotNull(responseInvoices);
        assertTrue(responseInvoices.length > 0);
        assertThat(result.status(), equalTo(OK));

    }

    @Test
    public void valid_user_should_get_month_to_date_invoices() {


        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(GET)
                .header(AuthUtils.AUTH_HEADER_KEY, token)
                .uri("/api/monthtodate");

        Result result = route(app, request);

        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        InvoiceResource[] responseInvoices = Json.fromJson(customDataJsonNode, InvoiceResource[].class);

        assertNotNull(responseInvoices);
        assertTrue(responseInvoices.length > 0);
        assertThat(result.status(), equalTo(OK));

    }

    @Test
    public void valid_user_should_get_year_to_date_invoices() {


        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(GET)
                .header(AuthUtils.AUTH_HEADER_KEY, token)
                .uri("/api/yeartodate");

        Result result = route(app, request);

        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        InvoiceResource[] responseInvoices = Json.fromJson(customDataJsonNode, InvoiceResource[].class);

        assertNotNull(responseInvoices);
        assertTrue(responseInvoices.length > 0);
        assertThat(result.status(), equalTo(OK));

    }

    @Test
    public void valid_user_should_get_quarter_to_date_invoices() {


        Http.RequestBuilder request = new Http.RequestBuilder()
                .method(GET)
                .header(AuthUtils.AUTH_HEADER_KEY, token)
                .uri("/api/quartertodate");

        Result result = route(app, request);

        JsonNode customDataJsonNode = Json.parse(contentAsString(result));

        InvoiceResource[] responseInvoices = Json.fromJson(customDataJsonNode, InvoiceResource[].class);

        assertNotNull(responseInvoices);
        assertTrue(responseInvoices.length > 0);
        assertThat(result.status(), equalTo(OK));

    }

}
